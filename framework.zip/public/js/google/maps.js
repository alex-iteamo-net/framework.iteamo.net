// ITEAMO.NET <<< ==============================================================
// Freelancer Alex Tert and IT specialists team.
// Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// skype: alexITmore  icq: 235004598  mail: alex@iteamo.net  web: iTeamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.google) === 'undefined') {
  iteamo.google = {}; 
}
iteamo.google.maps = {
// =============================================================================
  parseAddress: function(arAddress) {
    var arAddressResult = {};
    //
    var arMapping = {
      'country': {'arTypes': ['country']},
      'region': {'arTypes': ['administrative_area_level_1']},
      'city': {'arTypes': ['locality', 'administrative_area_level_2']},
      'street': {'arTypes': ['route']},
      'streetNumber': {'arTypes': ['street_number']},
      'office': {'arTypes': ['subpremise']},    
      'zip': {'arTypes': ['postal_code']}, 
    };
    //
    var arKeysByTypes = {};
    for(var key in arMapping) {
      for(var index in arMapping[key]['arTypes']) {
        var type = arMapping[key]['arTypes'][index];
        arKeysByTypes[type] = key;   
      }  
    }
    //
    for(var key in arAddress) {
      var arAddressPart = arAddress[key];
      for(var index in arAddressPart['types']) {
        var type = arAddressPart['types'][index];
        if (!empty(arKeysByTypes[type])) {
          arAddressResult[arKeysByTypes[type]] = arAddressPart['long_name'];
          break;   
        }   
      }
    }
    //
    if (empty(arAddressResult['region']) && !empty(arAddressResult['city'])) {
      arAddressResult['region'] = arAddressResult['city'];  
    }  
    if (!empty(arAddressResult['city'])) {
      arAddressResult['city'] = str_ireplace('Gorod', '', arAddressResult['city']);  
    }
    //
    // DEBUG <<<
    // console.log('arKeysByTypes'); console.log(arKeysByTypes);
    // console.log('arAddress'); console.log(arAddress);
    // console.log('arAddressResult'); console.log(arAddressResult);
    // >>> DEBUG
    //
    return arAddressResult;
  }, 
// -----------------------------------------------------------------------------
  findAddress: function (strAddress, arOptions) {
    var arAddress = ''; 
    //
    var url = 'https://maps.google.com/maps/api/geocode/json';
    url = url + '?address=' + strAddress;
    if (!empty(arOptions['key'])) {
      url = url + '&key=' + arOptions['key'];
    }
    //
    jQuery.ajax({
      url: url,
      async: false, dataType: 'json',
      success: function(data) {
        for (var key in data.results) {
          arAddress = data.results[key];
        } 
      }
    });
    return arAddress;
  }, 
// =============================================================================  
};
// =============================================================================
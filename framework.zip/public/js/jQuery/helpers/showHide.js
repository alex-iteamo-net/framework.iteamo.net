// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.jQuery) === 'undefined') {
  iteamo.jQuery = {}; 
}
iteamo.jQuery.showHide = {
// =============================================================================
  init: function(class) {
    jQuery(class).click(function(){
      var block = jQuery(this).attr('block');
      var objBlock = jQuery('.block.showHide[block="' + block + '"]');
      var objLink = jQuery(this); 
      var visible = objBlock.css('display');
      //
      if (!objLink.find('.arrow').length) {
        objLink.append('<span class="arrow"></span>');
      }
      var objArrow = objLink.find('.arrow');
      //
      if (visible != 'none') {
        objLink.attr('title', 'Открыть');
        objArrow.html('&#9658;');
      } else {    
        objLink.attr('title', 'Закрыть');      
        objArrow.html('&#9660;');    
      } 
      //
      objBlock.toggle(); 
    });
  }
// =============================================================================  
};
// =============================================================================
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
function is_array(mixed_var) {
  return (mixed_var instanceof Array);
}
function is_object(mixed_var) {
  return (mixed_var instanceof Object);
}
function empty(mixed_var) {  
  var result = (
    (typeof(mixed_var) === 'undefined') || 
    mixed_var === undefined || 
    mixed_var === '' || 
    mixed_var === 0 || 
    mixed_var === '0' || 
    mixed_var === null  || 
    mixed_var === false  || 
    (is_array(mixed_var) && mixed_var.length === 0) ||
    (is_object(mixed_var) && mixed_var.length === 0)
  );
  //
  return result;
}
function implode(glue, pieces) {
  return ((pieces instanceof Array) ? pieces.join (glue) : pieces);
}   
// =============================================================================
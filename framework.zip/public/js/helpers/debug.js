// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.helpers) === 'undefined') {
  iteamo.helpers = {}; 
}
iteamo.helpers.debug = {
// =============================================================================
  dump: function(arr, level) {
  	var dumped_text = '';
    //
  	if(!level) level = 0;
    //
  	var level_padding = "";
  	for(var j=0;j<level+1;j++) level_padding += "    ";
    //
  	if(typeof(arr) == 'object') {
  		for(var item in arr) {
  			var value = arr[item];
  			if(typeof(value) == 'object') {
  				dumped_text += level_padding + "'" + item + "' ...\n";
  				dumped_text += dump(value,level+1);
  			} else {
  				dumped_text += level_padding + "'" + item + "' => \"" + value + "\"\n";
  			}
  		}
  	} else {
  		dumped_text = '===>' + arr + '<===(' + typeof(arr) + ')';
  	}
    //
  	return dumped_text;
  }
// =============================================================================  
};
// =============================================================================
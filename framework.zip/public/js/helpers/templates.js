// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.helpers) === 'undefined') {
  iteamo.helpers = {}; 
}
iteamo.helpers.request = {
// =============================================================================
  parse : function(strTemplate, arData) {
    //
    // DEBUG <<<
    // strTemplate = "hey {name}, don't make it bad";
    // arData = {name: 'jude'};
    // >>> DEBUG
    //
    var strParsedTemplate = strTemplate.replace(/\{([a-zA-Z0-9 ]*)\}/g, function(m, key) {
      result = arData[key.trim()];
      return result;
    });
    //
    return strParsedTemplate;
  },
// =============================================================================  
};
// =============================================================================
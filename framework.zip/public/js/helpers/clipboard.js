// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.helpers) === 'undefined') {
  iteamo.helpers = {}; 
}
iteamo.helpers.clipboard = {
// =============================================================================
  get: function(containerId) {
    var result = false;
    //
    if (document.selection) { 
      var range = document.body.createTextRange();
      range.moveToElementText(document.getElementById(containerId));
      range.select().createTextRange();
      result = document.execCommand('Copy');         
    } else if (window.getSelection) {
      var range = document.createRange();
      objSelection = window.getSelection();
      objSelection.removeAllRanges();    
      range.selectNode(document.getElementById(containerId));
      objSelection.addRange(range);
      result = document.execCommand('Copy');
    }
    //
    return result;
  },
// =============================================================================  
};
// =============================================================================
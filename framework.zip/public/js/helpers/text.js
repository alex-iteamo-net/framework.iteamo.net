// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.helpers) === 'undefined') {
  iteamo.helpers = {}; 
}
iteamo.helpers.text = {
// =============================================================================
  upperFirstChar: function(text) {
    var textResult = '';  
    //
    if (!empty(text)) {
      textResult = text[0].toUpperCase() + text.substring(1)
    }
    //
    // DEBUG <<<
    // console.log('text', text);
    // console.log('textResult', textResult);
    // >>> DEBUG 
    //
    return textResult;
  },
// -----------------------------------------------------------------------------  
  translit: function(text, arMapping) {
    var textResult = '';
    //
    this.arMapping = {
      'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'jo', 'ж': 'zh',  
      'з': 'z', 'и': 'i', 'й': 'j', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r',
      'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh',  
      'щ': 'shc', 'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya'
    }  
    if (!empty(arMapping)) {
      this.arMapping = arMapping;
    }  
    if (empty(this.arMappingPrepared) || !empty(arMapping)) { 
      this.arMappingPrepared = this.arMapping;
      for(let stringFrom in this.arMapping) {
        let stringTo = this.arMapping[stringFrom];      
        this.arMappingPrepared[this.upperFirstChar(stringFrom)] = this.upperFirstChar(stringTo);
      }  
    }
    //
    for(i=0; i < text.length; i++) {
      let replacement = text[i];    
      if(this.arMappingPrepared[text[i]] !== undefined) {
        replacement = this.arMappingPrepared[text[i]];
      }  
      textResult += replacement;
    }
    //
    // DEBUG <<<
    // console.log('textResult', textResult);  
    // >>> DEBUG 
    //
    return textResult;
  },
// =============================================================================  
};
// =============================================================================
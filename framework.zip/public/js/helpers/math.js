// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.helpers) === 'undefined') {
  iteamo.helpers = {}; 
}
iteamo.helpers.math = {
// =============================================================================
  round: function(value, digitsAfterDecimal) {
    valueResult = value * 100;
    //
    valueResult = parseFloat(valueResult.toFixed(2));    
    valueResult = parseFloat(valueResult.toFixed(digitsAfterDecimal - 2)) / 100;
    valueResult = parseFloat(valueResult.toFixed(digitsAfterDecimal));
    //
    return valueResult;    
  }, 
// =============================================================================  
};
// =============================================================================
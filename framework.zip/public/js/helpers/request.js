// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
if (typeof(iteamo) === 'undefined') {
  iteamo = {};      
}
if (typeof(iteamo.helpers) === 'undefined') {
  iteamo.helpers = {}; 
}
iteamo.helpers.request = {
// =============================================================================
  getDataFromUrl: function(url) {
    var arData = {};
    if(typeof url != 'undefined' && url.indexOf('?')!== -1) {
      var urlSplit = url.split('?');
      var queryString = urlSplit[1];
      var queryParameters = queryString.split('&');
      for(var index=0; index < queryParameters.length; index++) {
      	var queryParam = queryParameters[index];
      	var queryParamComponents = queryParam.split('=');
      	arData[queryParamComponents[0]] = queryParamComponents[1];
      }
    }
    return arData;
  },
// -----------------------------------------------------------------------------  
  send: function(path, arData, arParams) {
    objPromise = null;
    //
    if (empty(arData)) arParams = {};
    if (empty(arParams)) arParams = {};
    //
    arParamsDefault = {
      dataType: 'json',
      type: 'POST',
    };
    arParams = jQuery.extend(false, {}, arParamsDefault, arParams);
    //
    arParams.data = arData;
    arParams.url = path;
    arParams.timeout = 30000;
    //
		objPromise = Promise.resolve(jQuery.ajax(arParams));        
    //
    return objPromise;
  },
// =============================================================================  
};
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo;
// =============================================================================
require_once(__dir__ . '/framework/app.php');
require_once(__dir__ . '/framework/traits/withSingleton.php');
require_once(__dir__ . '/framework/traits/withInheritance.php');
require_once(__dir__ . '/framework/traits/withServices.php');
// =============================================================================
/**
 *
 */   
class app extends framework\app {
// =============================================================================
use \iteamo\framework\traits\withSingleton;
use \iteamo\framework\traits\withInheritance;
use \iteamo\framework\traits\withServices;
// -----------------------------------------------------------------------------
// =============================================================================
}
// =============================================================================
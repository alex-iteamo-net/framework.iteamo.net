<?php
$CFG = array (
  'charsets' => 'cp1251 utf8 latin1',
  'lang' => 'ru',
  'time_web' => '600',
  'time_cron' => '600',
  'backup_path' => 'backup/',
  'backup_url' => 'backup/',
  'only_create' => 'MRG_MyISAM MERGE HEAP MEMORY',
  'globstat' => 0,
  'my_host' => 'localhost',
  'my_port' => '',
  'my_user' => 'u42765_admin',
  'my_pass' => 'L1g6M9b7',
  'my_comp' => 0,
  'my_db' => 'u42765_itickets',
  'auth' => 'mysql cfg',
  'user' => 'u42765_admin',
  'pass' => 'L1g6M9b7',
  'confirm' => '6',
  'exitURL' => './',
);
?>
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs\db\drivers;
// =============================================================================
class mysql {
// =============================================================================
public $dbConnection = null;
//
public $lastQuery = '';
public $queriesCount = 0;
public $debug = false;
//
private $base = '';
// -----------------------------------------------------------------------------
/**
 *
 */   
public function __construct($mixConnection = null, $arOptions = []) {
  if (!empty($arOptions['debug'])) {
    $this->debug = true;
  }    
  $this->connect($mixConnection);
}
/**
 *
 */     
public function connect($mixConnection = []) {  
  if (!empty($mixConnection)) {
    if (is_array($mixConnection)) {
      $mixConnection = array_replace(['host' => '', 'login' => '', 'password' => ''], $mixConnection);
      $objConnection = \mysqli_connect($mixConnection['host'], $mixConnection['login'], $mixConnection['password']);
    } else if (is_object($mixConnection)) {
      $objConnection = $mixConnection;   
    }
  } else {
    $objConnection = \mysqli_connect();
  }
  if (empty($objConnection)) {    
    die (\mysqli_error());
  }
  $this->setConnection($objConnection);  
  \mysqli_query($objConnection, 'SET NAMES "utf8"');
  //
  if (!empty($mixConnection['base'])) {
    $this->selectBase($mixConnection['base']);
  }      
  //
  // DEBUG <<< ---  
  // echo '$this->dbConnection'; echo '<br>'; print_r($this->dbConnection); echo '<hr>';   
  // >>> DEBUG ---
  // 
  return $this->dbConnection;        
} 
/**
 *
 */
public function disConnect() {
  mysqli_close($this->getConnection());
  $this->setConnection(null);
  if ($this->debug) {
    echo '<b>Queries count: ' . $this->queriesCount . ' </b> <hr>';
  }
} 
/**
 *
 */
public function selectBase($base = '') {
  \mysqli_select_db($this->getConnection(), $base) or die(mysql_error());
  $this->base = $base;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function getConnection() {
  return $this->objConnection;
} 
/**
 *
 */
public function setConnection($objConnection = null) {
  $this->objConnection = $objConnection;      
}     
// -----------------------------------------------------------------------------
/**
 *
 */ 
public function query($query = '') {
  //
  // DEBUG <<< ---    
  // echo '$query'; echo '<br>'; print_r($query); echo '<hr>';   
  // >>> DEBUG ---    
  //  
  $objResult = \mysqli_query($this->getConnection(), $query) or print(\mysqli_error($this->getConnection()));
  //  
  $this->queriesCount++;
  $this->lastQuery = $query;
  //  
  if ($this->debug) {
    echo '<br><b>Query #<'.$this->queriesCount.'>:</b> - ' . $query . ';<br>';
  }
  //
  // DEBUG <<< ---  
  // echo '$objResult'; echo '<br>'; print_r($objResult); echo '<hr>';   
  // >>> DEBUG ---
  // 
  return $objResult;
}
/**
 *
 */
public function getLastInsertId() {  
  $id = \mysqli_insert_id($this->getConnection());
  //
  return $id;
} 
/**
 *
 */
public function getAffectedRows() {  
  $result = \mysqli_affected_rows($this->getConnection());
  //
  return $result; 
}
/**
 *
 */
public function fetchRow($objResource = null) {
  $arItem = false;
  //
  $arItem = @\mysqli_fetch_array($objResource, \MYSQLI_ASSOC);
  //
  // DEBUG <<< ---
  // echo '$objResource'; echo '<br>'; print_r($objResource); echo '<hr>';  
  // echo '$arItem'; echo '<br>'; print_r($arItem); echo '<hr>';   
  // >>> DEBUG ---
  //  
  return $arItem;
} 
// ----------------------------------------------------------------------------- 
/**
 *
 */
public function tableExists($table = '', $base = null) {
  $result = false;
  //
  if (empty($base) and !empty($this->base)) {
    $base = $this->base;  
  }
  if (!empty($base)) {
    $sql = 'show tables where Tables_in_' . $base . " = '" . $table . "'";
    $objResult = $this->query($sql);  
    $arResult = $this->fetchRow($objResult);  
    $result = (count($arResult) > 0);
  }
  //
  return $result;  
}
// =============================================================================
}
// >>> ITEAMO ==================================================================
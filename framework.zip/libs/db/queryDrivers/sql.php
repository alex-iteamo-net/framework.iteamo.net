<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs\db\queryDrivers;
// =============================================================================
require_once(__dir__ . '/../../../helpers/arrays.php');
// =============================================================================
/**
 *
 */
class sql {
// =============================================================================
public $arSettings = [
  'whereDelimeter' => '|',
  'arOperators' => [
    'LIKE', 'IS', 'IN', '=', '>', '<', '>=', '<=', '<>',
  ],  
];
// -----------------------------------------------------------------------------
/**
 *
 */
public function calculateWhere($arFilters = [], $addBrackets = false) {
  $where = '';
  //
  $arWhereIncome = $arFilters;
  $logic = 'AND';
  $arWhereOutcome = [];
  //
  // DEBUG <<< ---
  // echo '$arWhereIncome:'; echo '<hr>'; print_r($arWhereIncome); echo '<hr>';
  // >>> DEBUG ---  
  //
  if (!empty($arWhereIncome)) {
    foreach($arWhereIncome as $key => $value) { 
      if ($key === 'logic') {
        $logic = strtoupper($value);
      } else {
        $arWhereOutcome[$key] = $this->calculateWhereItem($key, $value);  
      }
    }
  }
  //
  // DEBUG <<< ---
  // echo '$arWhereOutcome:'; echo '<hr>'; print_r($arWhereOutcome); echo '<hr>';
  // >>> DEBUG ---  
  //
  $where = implode(' ' . $logic . ' ', $arWhereOutcome);
  if ($addBrackets) {
    $where = '(' . $where . ')';
  }
  //
  return $where;
}
/**
 *
 */
protected function calculateWhereItem($key = '', $value = '') {
  $strCondition = '';
  //
  $arCondition = [
    'key' => $key,
    'operator' => '=',
    'value' => $value, 
  ];
  //
  if(is_string($key)) {
    if (is_array($value)) {
      if (!empty($value)) {
        if (
            \iteamo\framework\helpers\arrays::isPlain($value) 
            && !\iteamo\framework\helpers\arrays::isAssociative($value)
          ) {
            foreach($value as $keyInner => $valueInner) {
              $value[$keyInner] = '"' . $valueInner . '"';
            }        
            $arCondition['operator'] = 'IN';
            $arCondition['value'] = '(' . implode(', ', $value) . ')';                                  
        } else {
          $strCondition = $this->calculateWhere($value, true);
        }  
      } else {
        $arCondition['operator'] = 'IS';
        $arCondition['value'] = 'NULL';  
      }  
    } else {
      if (stripos($key, $this->arSettings['whereDelimeter']) !== false) {
        $arKey = explode($this->arSettings['whereDelimeter'], $key);
        $operator = $arKey[1];        
        if (in_array($operator, $this->arSettings['arOperators'])) { 
          $arCondition['key'] = $arKey[0];
          $arCondition['operator'] = $arKey[1];
        }
      }
      if (stripos($value, '%') !== false) {        
        $arCondition['operator'] = 'LIKE';
      }      
      if (stripos($value, $this->arSettings['whereDelimeter']) !== false) {
        $arValue = explode($this->arSettings['whereDelimeter'], $value);
        $operator = $arValue[0];
        if (in_array($operator, $this->arSettings['arOperators'])) { 
          $arCondition['operator'] = $arValue[0];
          $arCondition['value'] = $arValue[1];
        }                      
      }              
      if (is_string($arCondition['value'])) {
        if ($arCondition['value'] != 'NULL') {
          $arCondition['value'] = $this->escape($arCondition['value']);
          $arCondition['value'] = '"' . $arCondition['value'] . '"';          
        }  
      }      
    } 
  }
  //
  if (empty($strCondition)) {    
    $strCondition = implode(' ', $arCondition);
  }
  //
  // DEBUG <<< ---
  // echo '$key:'; echo '<hr>'; print_r($key); echo '<hr>';
  // echo '$value:'; echo '<hr>'; print_r($value); echo '<hr>';
  // echo '$strCondition:'; echo '<hr>'; print_r($strCondition); echo '<hr>';
  // echo '<hr>';
  // >>> DEBUG ---  
  //
  return $strCondition; 
} 
// -----------------------------------------------------------------------------
/**
 *
 */
protected function calculateSort($arSorts = []) {
  $sort = null;
  //
  $arSortIncome = $arSorts;
  $arSortOutcome = [];
  //
  foreach($arSortIncome as $key => $sortItem) {
    if (is_string($key)) {
      $field = $key;
      $order = $sortItem;
      $arSortOutcome[$field] = $field . ' ' . $order;
    } else {
      $arSortOutcome[] = $arSortItem;
    }
  }
  $sort = implode(', ', $arSortOutcome);
  //
  return $sort;
}
/**
 *
 */
protected function calculateJoin($arJoins = []) {
  $join = null;
  //
  $arJoinsIncome = $arJoins;
  $arJoinsOutcome = [];
  //
  foreach($arJoinsIncome as $joinTable => $mixJoin) {
    $arJoin = [];
    if (!is_array($mixJoin)) {
      $arJoin['type'] = 'LEFT';
      $arJoin['conditions'] = $mixJoin;
    } else {
      $arJoin = $mixJoin;
    }
    $arJoinsOutcome[] = $arJoin['type'] . ' JOIN ' . $joinTable . ' ON ' . $arJoin['conditions'];
  }
  $join = implode(' ', $arJoinsOutcome);
  //
  return $join;
}
/**
 *
 */
protected function calculateGroup($arGroups = []) {
  $group = null;
  //
  $group = implode(', ', $arGroups);
  //
  return $group;
}
/**
 *
 */
protected function calculateSelectFields($arSelectFields = []) {
  $selectFields = '*';
  //
  $arSelectFieldsProcessed = [];
  foreach($arSelectFields as $key => $value) {
    if (is_string($key) && $key != $value) {
      $arSelectFieldsProcessed[$key] = $value . ' AS ' . $key;
    } else $arSelectFieldsProcessed[$key] = $value;
  }
  //
  if (!empty($arSelectFields))
    $selectFields = implode(', ', $arSelectFieldsProcessed);
  //
  // DEBUG <<< ---
  // echo '$arSelectFields'; echo '<br>'; print_r($arSelectFields); echo '<hr>';
  // >>> DEBUG ---
  //
  return $selectFields;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function select($table = '', $arFilters = [], $arSorts = [], $arSelectFields = [], $arJoins = [], $arGroups = [], $arGroupsFilters = [], $limit = '') {
  $query = '';
  //
  $where = $this->calculateWhere($arFilters);
  $sort = $this->calculateSort($arSorts);
  $join = $this->calculateJoin($arJoins);
  $group = $this->calculateGroup($arGroups);
  $groupWhere = $this->calculateWhere($arGroupsFilters);
  $selectFields = $this->calculateSelectFields($arSelectFields);
  //
  if (!empty($sort)) $sort = ' ORDER BY ' . $sort;
  if (!empty($limit)) $limit = ' LIMIT ' . $limit;
  if (!empty($where)) $where = ' WHERE ' . $where;
  if (!empty($group)) $group = ' GROUP BY ' . $group . ' ';
  if (!empty($groupWhere)) $groupWhere = ' HAVING ' . $groupWhere;
  //
  $query = "SELECT $selectFields FROM  $table $join $where $group $groupWhere $sort $limit;";
  //
  // DEBUG <<< ---  
  // echo '$query'; echo '<br>'; print_r($query); echo '<hr>';
  // >>> DEBUG ---
  //
  return $query;
}
/**
 *
 */
public function selectCount($table = '', $arFilters = [], $arJoins = [])  {
  $query = '';
  //
  $where = $this->calculateWhere($arFilters);
  if (!empty($where)) {
    $where = 'WHERE ' . $where;
  }
  $join = $this->calculateJoin($arJoins);  
  //
  $query = "SELECT COUNT(*) FROM $table $join $where;";
  //
  return $query;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function insert($table = '', $arInsert = []) {
  $query = '';
  //
  $fieldNames = '';
  $fieldValues = '';
  //
  foreach ($arInsert as $key => $value) {
    $fieldNames = $fieldNames.' `'.$key.'` ,';
    if (is_string($value)) {
      $value = $this->escape($value);
    }
    if (is_null($value)) {
      $fieldValues = $fieldValues . ' NULL ,';
    } else {
      $fieldValues = $fieldValues . " '" . $value . "' ,";
    }
  }
  $fieldNames = substr($fieldNames, 0, strlen($fieldNames) - 1);
  $fieldValues = substr($fieldValues, 0, strlen($fieldValues) - 1);
  //
  $query = "INSERT into `$table` ($fieldNames) VALUES ($fieldValues);";
  //
  return $query;
}
/**
 *
 */
public function update($table = '', $arFilters = [], $arJoins = [], $arUpdate = []) {
  $query = '';
  //
  $where = $this->calculateWhere($arFilters);
  if (!empty($where)) {
    $where = 'WHERE ' . $where;
  }  
  $join = $this->calculateJoin($arJoins);
  //
  $changes = '';
  foreach ($arUpdate as $key => $value) {
    if (is_string($value)) {
      $value = $this->escape($value);
    }    
    if (is_null($value)) {
      $changes = $changes . " $key=NULL" . ',';
    } else {    
      $changes = $changes . " $key='$value'" . ',';
    }
  }
  $changes = substr($changes, 0, strlen($changes) - 1);
  //
  $query = "UPDATE `$table` SET $changes $join $where;";
  //
  return $query;
}
/**
 *
 */
public function delete($table = '', $arFilters = [], $arJoins = []) {
  $query = '';
  //
  $where = $this->calculateWhere($arFilters);
  if (!empty($where)) {
    $where = 'WHERE ' . $where;
  }  
  $join = $this->calculateJoin($arJoins);
  $query = "DELETE from `$table` $join $where;";   
  //
  return $query;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function escape($text = '') {
  $textResult = '';
  //
	$textResult = str_replace(
	  ['\\', "\0", "\n", "\r", "'", '"', "\x1a"],
	  ['\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'], $text);  
  //
  return $textResult;
}
// =============================================================================
}
// =============================================================================
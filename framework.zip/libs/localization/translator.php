<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs\localization;
// =============================================================================
require_once(__dir__ . '/../../framework/interfaces/translator.php');
require_once(__dir__ . '/../../framework/helpers/url.php');
require_once(__dir__ . '/../../framework/helpers/arrays.php');
require_once(__dir__ . '/../../framework/traits/withSettings.php');
// =============================================================================
use \iteamo\framework\helpers\url;
use \iteamo\framework\helpers\arrays;
// =============================================================================
/**
 * 
 */ 
class translator implements \iteamo\framework\interfaces\translator {
// =============================================================================
use \iteamo\framework\traits\withSettings;
// -----------------------------------------------------------------------------
protected $arSettings = [
  'defaultLanguage' => 'en',
  'arLanguages' => ['en', 'ru'],
  'directory' => '',
];
// -----------------------------------------------------------------------------
private $arTranslations = [];
// -----------------------------------------------------------------------------
/**
 *
 */
public function __construct($arSettings = []){
  $this->setSettings($arSettings);
  $this->setCurrentLanguage($this->getSetting('defaultLanguage'));
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function setCurrentLanguage($language = '') {
  if ($this->isValid($language)) {
    $this->currentLanguage = $language;
  }
}
/**
 *
 */
public function getCurrentLanguage() {
  return $this->currentLanguage;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function get($key = '', $arTranslations = [], $returnKey = true) {
  $translation = ($returnKey) ? $key : '';
  //    
  $this->setTranslationsByKey($key, $arTranslations);  
  // 
  $arLanguagesToCheck = arrays::unique([$this->getCurrentLanguage(), $this->getSetting('defaultLanguage')]);
  foreach($arLanguagesToCheck as $language) {
    $translationInner = $this->getInLanguage($key, $language, $returnKey = false); 
    if (!empty($translationInner)) {
      $translation = $translationInner;
      break;  
    }  
  }
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$arLanguagesToCheck'; echo '<br>'; print_r($arLanguagesToCheck); echo '<hr>';
  // echo '$translation'; echo '<br>'; print_r($translation); echo '<hr>';    
  // >>> DEBUG ---
  //
  return $translation;
}
/**
 *
 */
protected function getInLanguage($key = '', $language = '', $returnKey = true) {
  $translation = ($returnKey) ? $key : '';
  //     
  if ($this->isValid($language)) {    
    if (!empty($this->arTranslations[$language][$key])) {
      $translation = $this->arTranslations[$language][$key];       
    } else {
      $this->loadTranslationsFromFile($language);
      if (!empty($this->arTranslations[$language][$key])) {
        $translation = $this->arTranslations[$language][$key];
      }    
    }
  }
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$arLanguagesToCheck'; echo '<br>'; print_r($arLanguagesToCheck); echo '<hr>';
  // echo '$translation'; echo '<br>'; print_r($translation); echo '<hr>';    
  // >>> DEBUG ---
  //
  return $translation;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function setTranslationsByKey($key = '', $arTranslations = []) {
  if (!empty($arTranslations)) {
    foreach($arTranslations as $language => $translation) {
      if (empty($this->arTranslations[$language])) {
        $this->arTranslations[$language] = [];
      }
      $this->arTranslations[$language][$key] = $translation;
    }
  }
}
/**
 *
 */
public function setTranslationsByLanguage($language = '', $arTranslations = []) {
  if (!empty($arTranslations)) {
    if (empty($this->arTranslations[$language])) {
      $this->arTranslations[$language] = [];
    }    
    foreach($arTranslations as $key => $translation) {
      $this->arTranslations[$language][$key] = $translation;
    }
  }
}
// -----------------------------------------------------------------------------
/**
 *
 */
protected function loadTranslationsFromFile($language = '') {     
  $result = false;
  //
  if (!isset($this->arLoadedLanguages)) {
    $this->arLoadedLanguages = [];
  }  
  if (!in_array($language, $this->arLoadedLanguages)) {
    if (!isset($this->arTranslations[$language])) {
      $this->arTranslations[$language] = [];
    }     
    $arTranslationsFromFile = $this->getTranslationsFromFile($language);    
    $this->setTranslationsByLanguage($language, $arTranslationsFromFile);    
    $this->arLoadedLanguages[] = $language;        
  }
  //
  // DEBUG <<< ---
  // echo '$arTranslationsFromFile'; echo '<br>'; print_r($arTranslationsFromFile); echo '<hr>';    
  // >>> DEBUG ---
  //
  return $result; 
}
/**
 *
 */
protected function getTranslationsFromFile($language = '') {
  $arTranslationsFromFile = [];
  //     
  $path = $this->getSetting('directory') . '/' . $language . '.php';
  if (file_exists($path)) {
    require($path);
    if (!empty($arTranslations)) {
      $arTranslationsFromFile = $arTranslations;
    }
  }           
  //
  // DEBUG <<< ---
  // echo '$arTranslationsFromFile'; echo '<br>'; print_r($arTranslationsFromFile); echo '<hr>';    
  // >>> DEBUG ---
  //
  return $arTranslationsFromFile; 
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function isValid($language = '') {
  $result = (in_array($language, $this->getSetting('arLanguages')));
  //
  return $result;
}
/**
 *
 */
public function isDefault($language = '') {
  $result = ($language == $this->getSetting('defaultLanguage'));
  //
  return $result;
}
// =============================================================================
}
// =============================================================================
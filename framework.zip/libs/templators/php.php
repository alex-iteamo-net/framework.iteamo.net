<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs\templators;
// =============================================================================
require_once(__dir__ . '/../../framework/interfaces/templator.php');
require_once(__dir__ . '/../../framework/traits/withParent.php');
// =============================================================================
/**
 *
 */ 
class php implements \iteamo\framework\interfaces\templator {
// =============================================================================
use \iteamo\framework\traits\withParent;
// -----------------------------------------------------------------------------
/**
 * 
 */
public function setData($arData = []) {  
  if (!empty($arData)) {    
    $this->arData = $arData;    
    foreach($this->arData as $key => $mixValue) {    
      $this->$key = $this->arData[$key];           
    }    
  }
  //
  // DEBUG <<< ---
  // echo '$arData'; echo '<br>'; print_r($arData); echo '<hr>';
  // echo '$this->arResult'; echo '<br>'; print_r($this->arResult); echo '<hr>';
  // >>> DEBUG ---
  //   
  return $this;
}
/**
 *
 */
public function parse($path = '') {
  $strView = '';
  //
  if (file_exists($path)) {   
    ob_start();
      require($path);
      $strView = ob_get_contents();
    ob_end_clean();
  }
  //
  // DEBUG <<< ---
  // echo '$path'; echo '<br>'; print_r($path); echo '<hr>';
  // echo '$strView'; echo '<br>'; print_r($strView); echo '<hr>';  
  // >>> DEBUG ---
  //
  return $strView;
}
// =============================================================================
}
// =============================================================================
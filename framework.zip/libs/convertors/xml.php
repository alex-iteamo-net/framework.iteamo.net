<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs\convertors;
// =============================================================================
/**
 *
 */
class xml {
// =============================================================================  
  static protected $arSettings = [
    'version' => '1.0',
    'encoding' => 'UTF-8',
    'formatOutput' => true,
    'rootNode' => 'root',
  ];
// -----------------------------------------------------------------------------  
  /**
   *
   */
  public static function getObject($mixXml = null, $arSettings = []) {
    $objXml = null;
    //
    if (!empty($arSettings)) {
      self::$arSettings = array_replace(self::$arSettings, $arSettings);      
    }    
    //
    static $objXmlRoot = null;
    if (empty($objXmlRoot)) {
      $objXmlRoot = new \DomDocument(self::$arSettings['version'], self::$arSettings['encoding']);
      $objXmlRoot->formatOutput = self::$arSettings['formatOutput'];       
    }    
    $objXml = $objXmlRoot;
    //
    if (!empty($mixXml)) {
      $arXml = (is_array($mixXml)) ? $mixXml : self::getArray($mixXml); 
      $arXmlKeys = array_keys($arXml);
      if (count($arXmlKeys) >= 2) {
        throw new \exception('It could be only one root key node!');
      }  
      $rootNode = reset($arXmlKeys);        
      $objChild = self::convert($rootNode, $arXml[$rootNode]);      
      $objXml->appendChild($objChild);
      $objXmlRoot = null;
    }    
    //
    // DEBUG <<< ---
    // if (!empty($mixXml)) {
      // echo '$mixXml'; echo '<br>'; print_r($mixXml); echo '<hr>';
      // echo '$arXml'; echo '<br>'; print_r($arXml); echo '<hr>';
      // echo '$rootNode'; echo '<br>'; print_r($rootNode); echo '<hr>';      
      // echo '$arSettings'; echo '<br>'; print_r($arSettings); echo '<hr>';
      // echo 'self::$arSettings'; echo '<br>'; print_r(self::$arSettings); echo '<hr>';
      // echo '$objXml'; echo '<br>'; print_r($objXml); echo '<hr>';
      // echo '$objChild'; echo '<br>'; print_r($objChild); echo '<hr>';
    // }  
    // >>> DEBUG ---  
    //
    return $objXml;
  }
  /**
   *
   */
  public static function getString($arXml = [], $arSettings = []) {
    $strXml = '';
    //        
    $objXml = self::getObject($arXml, $arSettings);    
    $strXml = $objXml->saveXML();
    //
    // DEBUG <<< ---
    // echo '$arXml'; echo '<br>'; print_r($arXml); echo '<hr>';      
    // echo '$strXml'; echo '<br>'; print_r($strXml); echo '<hr>';  
    // >>> DEBUG ---  
    // 
    return $strXml;  
  }
  /**
   *
   */
  public static function getArray($strXml = '') {
    $arXml = [];
    //
    $arXmlTemp = \simplexml_load_string($strXml, 'SimpleXMLElement', \LIBXML_NOCDATA);
    $strXmlTemp = \json_encode($arXmlTemp);
    $arXml = \json_decode($strXmlTemp, $assoc = true, $depth = 512, JSON_BIGINT_AS_STRING);
    //
    // DEBUG <<< ---
    // echo '$strXml'; echo '<br>'; print_r($strXml); echo '<hr>';      
    // echo '$arXml'; echo '<br>'; print_r($arXml); echo '<hr>';  
    // >>> DEBUG ---  
    //     
    return $arXml;   
  }
// -----------------------------------------------------------------------------
  /**
   *
   */
  private static function convert($nodeName = '', $arXml = []) {    
    $objNode = null;
    //
    // DEBUG <<< ---
    // echo '$nodeName'; echo '<br>'; print_r($nodeName); echo '<hr>';      
    // echo '$arXml'; echo '<br>'; print_r($arXml); echo '<hr>';      
    // >>> DEBUG ---  
    // 
    $objXml = self::getObject();    
    $objNode = $objXml->createElement($nodeName);            
    //    
    if(is_array($arXml)) {
      if(isset($arXml['@attributes'])) {
        foreach($arXml['@attributes'] as $key => $value) {
          if(!self::isValidTagName($key)) {
            throw new \exception('[Array2XML] Illegal character in attribute name. attribute: ' . $key . ' in node: ' . $nodeName);
          }
          $objNode->setAttribute($key, self::bool2str($value));
        }
        unset($arXml['@attributes']);
      }        
      if(isset($arXml['@value'])) {
        $objNode->appendChild($objXml->createTextNode(self::bool2str($arXml['@value'])));
        unset($arXml['@value']);
        return $objNode;
      } else if(isset($arXml['@cdata'])) {
        $objNode->appendChild($objXml->createCDATASection(self::bool2str($arXml['@cdata'])));
        unset($arXml['@cdata']);        
        return $objNode;
      }
    }    
    //    
    if(is_array($arXml)) {        
      foreach($arXml as $key => $value) {            
        if(!self::isValidTagName($key)) {                    
          throw new \exception('[Array2XML] Illegal character in tag name. tag: ' . $key . ' in node: ' . $nodeName);
        }            
        if(is_array($value) && is_numeric(key($value))) {
          foreach($value as $keyInner => $valueInner){
            $objNode->appendChild(self::convert($key, $valueInner));
          }
        } else {                
          $objNodeInner = self::convert($key, $value);                 
          $objNode->appendChild($objNodeInner);
        }
        unset($arXml[$key]);
      }
    }    
    if(!is_array($arXml)) {
      $objNode->appendChild($objXml->createTextNode(self::bool2str($arXml)));
    }
    //
    // DEBUG <<< ---          
    // echo '$arXml'; echo '<br>'; print_r($arXml); echo '<hr>';
    // echo '$objNode'; echo '<br>'; print_r($objNode); echo '<hr>';  
    // >>> DEBUG ---  
    // 
    return $objNode;
  }
// -----------------------------------------------------------------------------  
  /*
   * Get string representation of boolean value
   */
  protected static function bool2str($v = false){
    $v = ($v === true) ? 'true' : $v;
    $v = ($v === false) ? 'false' : $v;
    //
    return $v;
  }
  /*
   * Check if the tag name or attribute name contains illegal characters
   * Ref: http://www.w3.org/TR/xml/#sec-common-syn
   */
  protected static function isValidTagName($tag = '') {
    $pattern = '/^[a-zа-я_]+[a-zа-я0-9\:\-\.\_]*[^:]*$/iu';
    //
    return preg_match($pattern, $tag, $matches) && $matches[0] == $tag;
  }
// =============================================================================
}
// =============================================================================
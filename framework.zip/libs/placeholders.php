<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs;
// =============================================================================
require_once(__dir__ . '/../framework/traits/withSettings.php');
// =============================================================================
/**
 * 
 */ 
class placeholders {
// =============================================================================
use \iteamo\framework\traits\withSettings;
// -----------------------------------------------------------------------------
protected $arData = [];
protected $arSettings = [
  'start' => '{{',
  'end' => '}}',
];
// -----------------------------------------------------------------------------
/**
 *
 */
public function __construct($arSettings = []){
  $this->setSettings($arSettings);
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function setValue($key = '', $value = '') {
  if (empty($value)) {
    $value = $key;
  }
  $this->arData[$key] = $value;  
}
/**
 *
 */
public function getValue($key = '') {
  $value = null;
  //
  if (!empty($this->arData[$key])) {
    $value = $this->arData[$key];
  }
  //
  return $value;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function get($key = '', $value = '') {
  $strPlaceholder = $this->getSetting('start') . $key . $this->getSetting('end');  
  $this->setValue($key, $value);
  //  
  return $strPlaceholder;
}
/**
 *
 */
public function replace($text = '') {  
  foreach($this->arData as $key => $value) {
    $text = str_ireplace($this->getSetting('start') . $key . $this->getSetting('end'), $value, $text);
  }
  //
  // DEBUG <<< ---
  // echo '$this->arData'; echo '<br>'; print_r($this->arData); echo '<hr>';
  // echo '$text'; echo '<br>'; print_r($text); echo '<hr>';
  // >>> DEBUG ---
  //     
  //
  return $text;      
} 
// =============================================================================
}
// =============================================================================
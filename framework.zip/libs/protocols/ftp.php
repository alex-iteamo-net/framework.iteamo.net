<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\libs\protocols;
// =============================================================================
/**
 *
 */  
class ftp {
// =============================================================================
protected $objConnection = null;
// -----------------------------------------------------------------------------
/**
 *
 */
public function connect($arCredentials = [], $arOptions = []) {
  $result = false;
  //
  $arCredentials = array_replace(['host' => '', 'port' => 21, 'login' => '', 'password' => ''], $arCredentials);
  $arOptions = array_replace(['timeout' => 30], $arOptions);
  //
  $this->objConnection = \ftp_connect($arCredentials['host'], $arCredentials['port'], $arOptions['timeout']);
  if (empty($this->objConnection)) {
    throw new \exception('Не удалось подключить к FTP-серверу');
  }
  if (!\ftp_login($this->objConnection, $arCredentials['login'], $arCredentials['password'])) {
    throw new \exception('Не удалось авторизоваться на FTP-сервере');
  } 
  //
  \ftp_pasv($this->objConnection, true);  
  $result = true;
  //
  // DEBUG <<< ---
  // echo '$arCredentials'; echo '<br>'; print_r($arCredentials); echo '<hr>';         
  // >>> DEBUG ---
  //
  return $result;  
}
/**
 *
 */
public function downloadFile($pathRemote = '', $pathLocal = '') {
  $result = false;
  //
  if (empty($this->objConnection)) {    
    throw new \exception('Подключитесь к FTP-серверу!');
  }        
  if (!\ftp_get($this->objConnection, $pathLocal, $pathRemote, \FTP_ASCII, 0)) {
    throw new \exception('Ошибка скачивания файла с FTP-сервера');
  }    
  //
  $result = true;   
  //
  // DEBUG <<< ---
  // echo '$pathRemote'; echo '<br>'; print_r($pathRemote); echo '<hr>';
  // echo '$pathLocal'; echo '<br>'; print_r($pathLocal); echo '<hr>';         
  // >>> DEBUG ---
  //
  return $arResult;
} 
/**
 *
 */
public function getModificationDate($pathRemote = '', $format = 'd.m.Y H:i:s') {
  $dateModification = '';
  //
  if (empty($this->objConnection)) {    
    throw new \exception('Подключитесь к FTP-серверу!');
  }    
  //
  $dateModification = date($format, \ftp_mdtm($this->objConnection, $pathRemote));
  //
  // DEBUG <<< ---
  // echo '$this->objConnection'; echo '<br>'; print_r($this->objConnection); echo '<hr>';
  // echo '$pathRemote'; echo '<br>'; print_r($pathRemote); echo '<hr>';
  // echo '$dateModification'; echo '<br>'; print_r($dateModification); echo '<hr>';         
  // >>> DEBUG ---
  //
  return $dateModification;  
}
/**
 *
 */
public function close() {
  $result = false;
  //
  $result = \ftp_close($this->objConnection);
  //
  return $result;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function __destruct() {
  $this->close();
}
// =============================================================================
}
// =============================================================================
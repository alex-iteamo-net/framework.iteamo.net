<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
require_once(__dir__ . '/../helpers/log.php');
// =============================================================================
/**
 *
 */
trait withLogs {
// =============================================================================
/**
 *
 */
public function log($arData = [], $key = 'main') {
  $result = false;
  // 
  if (empty($this->arPaths['logs'])) {
    throw(new \exception('Specify logs path'));
  }
  //
  if (empty($arData['datetime'])) {
    $arData = array_replace(['datetime' => date('d.m.Y H:i')], $arData);
  }
  $path = $this->arPaths['logs'] . '/' . $key . '.log';
  $result = \iteamo\framework\helpers\log::write($path, $arData);
  //
  return $result; 
}
// =============================================================================
}
// =============================================================================
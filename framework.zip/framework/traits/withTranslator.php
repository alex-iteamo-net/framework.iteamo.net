<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
/**
 *
 */
trait withTranslator {
// =============================================================================
/**
 *
 */
public function translate($key = '', $arTranslations = [], $returnKey = true) {  
  $translation = '';
  //
  $objTranslator = $this->getTranslator();
  $translation = $objTranslator->get($key, $arTranslations, $returnKey);    
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$translation'; echo '<br>'; print_r($translation); echo '<hr>';    
  // >>> DEBUG ---
  //
  return $translation;
}
/**
 *
 */
protected function getTranslator() {
  $objTranslator = null;
  //  
  if (method_exists($this, 'getService')) {
    $objTranslator = $this->getService('translator');  
  }
  if (empty($objTranslator)) {
    throw new \exception('You should specify `translator` service');
  }  
  //
  return $objTranslator;
}
// =============================================================================
}
// =============================================================================
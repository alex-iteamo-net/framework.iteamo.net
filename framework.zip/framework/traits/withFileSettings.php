<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
require_once(__dir__ . '/withSettings.php');
// =============================================================================
/**
 *
 */
trait withFileSettings {
// =============================================================================
use \iteamo\framework\traits\withSettings;
// -----------------------------------------------------------------------------
/**
 *
 */
public function getSettings($mixKeys = null) {
  $mixResult = null;
  //
  $arSettings = $this->getSettingsFromFile();
  if (!empty($this->arSettings)) {
    $arSettings = array_replace($arSettingsFromFile, $this->arSettings);  
  } 
  $mixResult = \iteamo\framework\helpers\arrays::get($arSettings, $mixKeys);
  //
  return $mixResult;
}   
/**
 *
 */
protected function getSettingsFromFile($first = true) {
  static $arSettingsFromFile = null;
  //  
  if (is_null($arSettingsFromFile)) {
    $path = $this->getPath('settings');
    if (!empty($path)) {
      if (file_exists($path)) {
        require($path);
      }
      $arSettingsFromFile = (!empty($arSettings)) ? $arSettings : [];
    }    
  }
  //
  return $arSettingsFromFile; 
}
// =============================================================================
}
// =============================================================================
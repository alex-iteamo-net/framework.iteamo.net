<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
/**
 *
 */
trait withTemplator {
// =============================================================================
/**
 *
 */
public function parseTemplate($keyPath = '', $arData = []) {  
  $strResult = '';
  //
  $objTemplator = $this->getTemplator();  
  $path = ($keyPath{0} != '/') ? $this->getPath($keyPath) : $keyPath;  
  $strResult = $objTemplator->setData($arData)->parse($path);      
  //
  // DEBUG <<< ---
  // echo '__method__'; echo '<br>'; print_r(__method__); echo '<hr>';  
  // echo '$keyPath'; echo '<br>'; print_r($keyPath); echo '<hr>';  
  // echo '$arData'; echo '<br>'; print_r($arData); echo '<hr>';  
  // echo '$path'; echo '<br>'; print_r($path); echo '<hr>';  
  // echo '$result'; echo '<br>'; print_r($result); echo '<hr>';
  // echo 'get_class($this)'; echo '<br>'; print_r(get_class($this)); echo '<hr>';
  // echo 'strlen($strResult)'; echo '<br>'; print_r(strlen($strResult)); echo '<hr>';      
  // >>> DEBUG ---
  //
  return $strResult;
}
/**
 *
 */
protected function getTemplator() {
  $objTemplator = null;
  //  
  if (method_exists($this, 'getService')) {
    $objTemplator = $this->getService('templator');  
  }
  if (empty($objTemplator)) {
    throw new \exception('You should specify `templator` service');
  }  
  //
  return $objTemplator;
}
// =============================================================================
}
// =============================================================================
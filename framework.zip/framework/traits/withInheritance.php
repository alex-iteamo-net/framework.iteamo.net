<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
require_once(__dir__ . '/../helpers/arrays.php');
require_once(__dir__ . '/../helpers/path.php');
require_once(__dir__ . '/../helpers/classes.php');
// =============================================================================
use \iteamo\framework\helpers\arrays;
use \iteamo\framework\helpers\path;
use \iteamo\framework\helpers\classes;
// =============================================================================
/**
 *
 */
trait withInheritance {
// =============================================================================
/**
 *
 */
public function getSettings($mixKeys = null) {  
  $mixResult = [];
  //  
  $arSettings = parent::getSettings();
  //  
  $objParentClass = $this->getApp('parent'); 
  if (!empty($objParentClass)) {     
    $arSettingsParent = $objParentClass->getSettings();        
    $arSettings = arrays::mergeUpdate($arSettingsParent, $arSettings, 'recursive');    
  }
  $mixResult = arrays::get($arSettings, $mixKeys);
  //
  return $mixResult;
}
/**
 *
 */
public function getPath($key = 'root', $arOptions = []) {  
  $keyFormatted = path::format($key);
  if ($keyFormatted{0} == '\\') {
    $arOptions['withoutInheritance'] = true;    
  }  
  $path = parent::getPath($key, $arOptions);    
  //
  if (empty($path) && empty($arOptions['withoutInheritance'])) {    
    $objParentClass = $this->getApp('parent');    
    if (!empty($objParentClass)) {      
      $path = $objParentClass->getPath($key, $arOptions);
    }
  }
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';    
  // echo '$path'; echo '<br>'; print_r($path); echo '<hr>'; 
  // >>> DEBUG ---  
  //   
  return $path;
}
/**
 *
 */
public function getClass($key = '', $arOptions = []) {
  $class = null;
  //
  $keyFormatted = classes::format($key);
  if ($keyFormatted{0} == '\\') {
    $arOptions['withoutInheritance'] = true;    
  }
  //
  $arOptionsToPass = array_replace($arOptions, [
    'withoutInheritance' => true,
    'withoutException' => empty($arOptions['withoutInheritance']),    
  ]);
  $class = parent::getClass($key, $arOptionsToPass);    
  //
  if (empty($class) && empty($arOptions['withoutInheritance'])) {    
    $objParentClass = $this->getApp('parent');    
    if (!empty($objParentClass)) {      
      $class = $objParentClass->getClass($key, $arOptions);
    }
  }
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';    
  // echo '$class'; echo '<br>'; print_r($class); echo '<hr>'; 
  // >>> DEBUG ---  
  //   
  return $class;
}
// =============================================================================
}
// =============================================================================
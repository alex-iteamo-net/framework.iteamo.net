<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
/**
 *
 */ 
trait withParent {
// =============================================================================
protected $objParent = null;
// -----------------------------------------------------------------------------
/**
 *
 */
public function setParent($objParent = null) {
  $this->objParent = $objParent;
  //
  // DEBUG <<< ---
  // echo '__method__'; echo '<br>'; print_r(__method__); echo '<hr>';  
  // echo 'get_class($this)'; echo '<br>'; print_r(get_class($this)); echo '<hr>';
  // echo 'get_class($objParent)'; echo '<br>'; print_r(get_class($objParent)); echo '<hr>';        
  // >>> DEBUG ---
  //
  return $this;
}
/**
 *
 */
public function getParent() {
  return $this->objParent;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function __call($method = '', $arParams = []) {
  $mixResult = null;
  //
  if ($objParent = $this->getParent()) {    
    if (method_exists($objParent, $method)) {      
      $mixResult = call_user_func_array([$objParent, $method], $arParams);
    } else {
      die($method . ' does not exist!');
    }
  }
  //
  return $mixResult;
}
/**
 *
 */
public function __get($key = '') {
  $mixResult = [];
  //  
  if ($objParent = $this->getParent()) {
    if (isset($objParent->$key)) {
      $mixResult = $objParent->$key;
    }
  }
  //
  return $mixResult;
}
/**
 *
 */
public function __set($key = '', $value = '') {
  $objParent = $this->getParent();
  if (!empty($objParent) && isset($objParent->$key)) {    
    $objParent->$key = $value;
  } else {
    $this->$key = $value;
  }
  //
  // DEBUG <<< ---  
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$value'; echo '<br>'; print_r($value); echo '<hr>';      
  // >>> DEBUG ---
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
require_once(__dir__ . '/../helpers/arrays.php');
// =============================================================================
/**
 *
 */
trait withSettings {
// =============================================================================
/**
 *
 */
public function getSettings($mixKeys = null) {   
  $mixResult = [];
  //
  if (!isset($this->arSettings)) {
    $this->arSettings = [];
  }  
  $mixResult = \iteamo\framework\helpers\arrays::get($this->arSettings, $mixKeys);
  //
  return $mixResult;
}
/**
 *
 */
public function setSettings($arSettings = []) {
  if (!isset($this->arSettings)) {
    $this->arSettings = [];
  }
  $this->arSettings = \iteamo\framework\helpers\arrays::set($this->arSettings, $arSettings);
} 
// -----------------------------------------------------------------------------
/**
 *
 */
public function getSetting($key = '') {   
  $result = '';
  //  
  $result = $this->getSettings($key);
  //
  return $result;
}
/**
 *
 */
public function setSetting($key = '', $value = '') {
  $this->arSettings = $this->setSettings([$key => $value]);
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
require_once(__dir__ . '/../helpers/mapping.php');
// =============================================================================
/**
 *
 */  
trait withEntityInterface {
// =============================================================================
public $arFields = [];
public $arDependentFields = [];
//  ----------------------------------------------------------------------------
protected $reset = true;
protected $arFilters = [];
protected $arSorts = [];
protected $limit = '';
// -----------------------------------------------------------------------------
/**
 *
 */
public function reset($reset = null)  {
  if ($this->reset) {
    foreach(['limit'] as $field) {
      $this->$field = '';
    }
    foreach(['arFilters', 'arSorts'] as $field) {
      $this->$field = [];
    }
  }
  //
  return $this;
}
/**
 *
 */
public function setReset($reset = true) {
  $this->reset = $reset;
  //
  return $this;  
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function filter($arFilters = []) {
  if (is_array($arFilters)) {
    $this->arFilters = array_merge($this->arFilters, $arFilters);
  } else {
    $this->arFilters = [];  
  }
  //
  // DEBUG <<< -----
  // echo '$arFilters'; echo '<br>'; print_r($arFilters); echo '<hr>';
  // echo '$this->arFilters'; echo '<br>'; print_r($this->arFilters); echo '<hr>';
  // >>> DEBUG -----
  //
  return $this;
}
/**
 *
 */
public function sort($arSorts = []) {
  if (is_array($arSorts)) {
    $this->arSorts = array_merge($this->arSorts, $arSorts);
  } else {
    $this->arSorts = [];  
  }  
  //
  // DEBUG <<< -----
  // echo '$arSorts'; echo '<br>'; print_r($arSorts); echo '<hr>';
  // >>> DEBUG -----
  //
  return $this;
}
/**
 *
 */
public function limit() {
  $arParams = func_get_args();
  if (!empty($arParams)) {
    $this->limit = implode(', ', $arParams);
  }
  //
  return $this;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function select($arSelectFields = []) {
  $result = null;
  //
  // DEBUG <<< -----
  // echo '$arSelectFields'; echo '<br>'; print_r($arSelectFields); echo '<hr>';
  // echo '$result'; echo '<br>'; print_r($result); echo '<hr>';
  // >>> DEBUG -----
  //
  return $result;
}
/**
 *
 */
public function selectOne($arSelectFields = []) {
  $result = null;
  //
  $resultInner = $this->limit(1)->select($arSelectFields);
  if (!empty($resultInner)) {
    $result = current($resultInner);
  }
  //
  // DEBUG <<< -----
  // echo '$arSelectFields'; echo '<br>'; print_r($arSelectFields); echo '<hr>';
  // echo '$result'; echo '<br>'; print_r($result); echo '<hr>';
  // >>> DEBUG -----
  //
  return $result;
}
/**
 *
 */
public function selectCount() {
  $count = 0;
  //
  $arItems = $this->select();
  $count = count($arItems);
  //
  return $count;
}
// -----------------------------------------------------------------------------
/**
 *
 */
protected function getItems($mixItems = null, $arSelectFields = []) {
  $arItems = [];
  //
  $arSelectFieldsPrepared = $arSelectFields; 
  if (!is_array($arSelectFields)) {
    $selectOneField = $arSelectFields;
    $arSelectFieldsPrepared = [$arSelectFields];      
  }  
  while ($arItem = $this->fetchItem($mixItems, $arSelectFieldsPrepared)) {
    $arItems[] = $arItem;
  }
  if (!empty($selectOneField)) {
    $arItems = array_map(function($arItem = []) use ($selectOneField) {
      return (isset($arItem[$selectOneField])) ? $arItem[$selectOneField] : null;    
    }, $arItems);
  }  
  //
  // DEBUG <<< ------
  // echo '$objItems'; echo '<br>'; print_r($objItems); echo '<hr>';
  // >>> DEBUG ------
  //
  return $arItems;
}
/**
 *
 */
protected function getItem(&$mixItems = null, $arSelectFields = []) {
  $mixResult = null;
  //
  $arItem = $this->getItemInner($mixItems);
  if (!empty($arItem)) {
    $mixResult = $this->prepareItem($arItem, $arSelectFields);
  }
  //
  // DEBUG <<< -----        
  // echo '$mixResult'; echo '<br>'; print_r($mixResult); echo '<hr>';                  
  // >>> DEBUG -----
  // 
  return $mixResult;
}
/**
 *
 */
protected function getItemInner(&$mixItems = null) {
  $arItem = null;
  //
  if (!empty($mixItems)) {
    $arItem = array_shift($mixItems);
  }
  //
  // DEBUG <<< -----
  // echo '$arItem'; echo '<br>'; print_r($arItem); echo '<hr>';
  // >>> DEBUG -----
  //
  return $arItem;
}
/**
 *
 */
protected function prepareItem($arItem = [], $arSelectFields = []) {       
  $arItemPrepared = $arItem;
  //
  // DEBUG <<< -----
  // echo '$arItem'; echo '<br>'; print_r($arItem); echo '<hr>';
  // echo '$arItemPrepared'; echo '<br>'; print_r($arItemPrepared); echo '<hr>';  
  // >>> DEBUG -----
  //
  return $arItemPrepared;
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\traits;
// =============================================================================
/**
 *
 */
trait withServices {
// =============================================================================
/**
 *
 */
public function setService($key = '', $object = null) {
  $this->arServices[$key] = $object;  
}
/**
 *
 */
public function getService($key = '') {
  $objService = null;
  //
  if (!empty($this->arServices[$key])) {
    $objService = $this->arServices[$key];
  }
  //
  return $objService;  
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 * 
 */   
class path {
// =============================================================================
private static $documentRoot = '';
// -----------------------------------------------------------------------------
/**
 *
 */
static public function setDocumentRoot($documentRoot = '') {
  $documentRoot = static::format($documentRoot);
  self::$documentRoot = $documentRoot;
}
/**
 *
 */
static public function getDocumentRoot($documentRoot = '') {
  if (empty(static::$documentRoot)) {
    self::setDocumentRoot($_SERVER['DOCUMENT_ROOT']);  
  }
  $documentRoot = self::$documentRoot;
  //
  return $documentRoot;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getRelative($path = '') {
  $result = static::format($path);
  //
  if (stripos($result, static::getDocumentRoot()) === 0) {
    $result = str_ireplace(static::getDocumentRoot(), '', $result);
  }
  //
  return $result;
} 
/**
 *
 */
static public function getAbsolute($path = '') {
  $result = static::format($path);
  //
  if (stripos($result, static::getDocumentRoot()) !== 0) {
    $result = static::getDocumentRoot() . $result;
  }
  //
  return $result;
}
// ----------------------------------------------------------------------------- 
/**
 *
 */
static public function format($path = '') {
  $result = '';
  //  
  $result = rtrim(str_ireplace(['\\', '//'], '/', trim($path)), '/');  
  //
  return $result;
}
// -----------------------------------------------------------------------------
/**
 *
 */ 
static public function getDirectory($path = '') {
  $result = dirname(static::format($path));
  //
  return $result;
}
/**
 *
 */ 
static public function getFileName($path = '') {
  $result = basename(static::format($path));
  //
  return $result;
}
/**
 *
 */
static public function getExtension($path = '') {
  $extension = null;
  //
  $arTemp = explode('.', static::format($path));
  if (count($arTemp) >= 2) {
    $extension = end($arTemp); 
  }  
  //
  return $extension;
}
/**
 *
 */
static public function getSegments($path = '') {
  $arPathSegments = [];
  //
  $arPathSegments = explode('/', static::format($path));
  //
  return $arPathSegments;
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 *
 */ 
class phones {
// =============================================================================
/**
 *
 */
static public function parse($strPhones = '', $mode = '') { 
  $arPhones = [];
  //
  $arPhonesTemp = [];
  preg_match_all('/\b([a-z0-9._-]+@[a-z0-9.-]+)\b/isu', $strPhones, $arPhonesTemp);
  if (!empty($arMailsTemp[0])) {
    $arMailsTemp = $arMailsTemp[0];
    foreach($arMailsTemp as $mail) {
      if ($mode == 'returnParts') {
        $arMail = explode('@', $mail);
        $arMails[] = ['user' => $arMail[0], 'domain' => $arMail[1]];    
      } else {
        $arMails[] = $mail;
      }  
    }
    $arPhones = array_unique($arPhones);
  }
  //
  // DEBUG <<<
  // echo '$strPhones'; echo '<br>'; print_r($strPhones); echo '<hr>';
  // echo '$arPhonesTemp'; echo '<br>'; print_r($arPhonesTemp); echo '<hr>';
  // echo '$arPhones'; echo '<br>'; print_r($arPhones); echo '<hr>';
  // >>> DEBUG   
  //
  return $arPhones; 
} 
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 *
 */
class response {
// =============================================================================
/**
 *
 */
public static function emit($mixResponse = null) {
  if (!empty($mixResponse)) {
    $arResponse = (is_array($mixResponse)) ? $mixResponse : ['content' => $mixResponse];   
    if (!empty($arResponse['arHeaders'])){
      static::emitHeaders($arResponse['arHeaders']);
    }
    echo $arResponse['content'];
  }
  die();
}
/**
 *
 */
public static function emitHeaders($arHeaders = []) {
  if (in_array('404', $arHeaders)){
    header('HTTP/1.0 404 Not Found');
    header('HTTP/1.1 404 Not Found');
    header('Status: 404 Not Found');
  }
}
// =============================================================================
}
// =============================================================================
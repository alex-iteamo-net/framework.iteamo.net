<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 * 
 */   
class encoding {
// =============================================================================
/**
 *
 */
static public function getName($text = '') {
  $encoding = null;
  //
  $encoding = mb_detect_encoding($text, 'auto', true);
  if (empty($encoding)) {
    $encoding = 'windows-1251'; 
  }
  //
  // DEBUG <<< ---          
  // echo '$encoding'; echo '<br>'; print_r($encoding); echo '<hr>';             
  // >>> DEBUG ---
  // 
  return $encoding;  
} 
/**
 *
 */
static public function get($text,  $encodingFrom = '', $encodingTo = '') {  
  $result = $text;
  //   
  if ($encodingTo != $encodingFrom) {            
    $result = 
    if (function_exists('iconv')) {
      $result = \iconv($encodingFrom, $encodingTo, $text);
    } else {
      if (($encodingFrom == 'cp1251') && ($encodingTo == 'utf-8')) {
        $mode = 'winToUtf';
      }
      if (($encodingFrom == 'utf-8') && ($encodingTo == 'cp1251')) {
        $mode = 'utfToWin';
      }       
      if (!empty($mode)) { 
        $result = self::iconvEmulator($mixInput, $mode);
      }
    }                        
  }    
  //
  // DEBUG <<< ---
  // echo '$text'; echo '<br>'; print_r($text); echo '<hr>';      
  // echo '$encodingCurrent'; echo '<br>'; print_r($encodingCurrent); echo '<hr>';
  // $mixText = mb_convert_encoding($mixText, $encodingTo, $encodingFrom);     
  // >>> DEBUG ---
  //  
  return $result;
}
/**
 *
 */
public static function iconvEmulator($text = '', $mode = 'winToUtf') {
  $result = $text;
  //
  static $conv = '';
  if (!is_array($conv)) {
    $conv = [];
    for ($x = 129; $x <= 143; $x++) {
      $conv['utf'][] = chr(209) . chr($x);
      $conv['win'][] = chr($x + 112);
    }
    for ( $x=144; $x <=191; $x++ ) {            
      $conv['utf'][] = chr(208) . chr($x);
      $conv['win'][] = chr($x + 48);
    }
    $conv['utf'][] = chr(208) . chr(129);
    $conv['win'][] = chr(168); // Ё
    $conv['utf'][] = chr(209) . chr(145);
    $conv['win'][] = chr(184); // ё
    $conv['utf'][] = chr(209) . chr(128);
    $conv['win'][] = chr(240); // р
  }
  if ($mode == 'utfToWin') {
    $result = str_replace($conv['utf'], $conv['win'], $text);
  } elseif ($mode == 'winToUtf') {
    $result = str_replace($conv['win'], $conv['utf'], $text);
  }
  //
  return $result;  
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 * 
 */   
class color {
// =============================================================================
/**
 *
 */ 
static public function hex2rgb($color = '') {
  $rgb = [0, 0, 0];
  //
  if (preg_match('/^#?(?P<color>\w{3}|\w{6})$/', $color, $match)) {
    $mod = strlen($match['color']) / 3;
    foreach(str_split($match['color'], $mod) as $key => $value) {
      $rgb[$key] = hexdec(($mod == 2) ? $value : $value . $value);
    }
  }
  //
  return $rgb;
}
// =============================================================================
}
// =============================================================================
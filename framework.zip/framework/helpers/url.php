<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 * 
 */ 
class url {
// =============================================================================
/**
 *
 */
public static function get($mixUrl = null, $mixKeys = null) {
  $mixResult = null;
  //    
  if ($mixUrl == 'current') {
    $mixUrl = null;
  }
  $arUrl = static::parse($mixUrl);
  //
  if (arrays::in('arHostSegments', $mixKeys)) {
    $arUrl['arHostSegments'] = static::getHostSegments($arUrl);
  }
  if (arrays::in('arPathSegments', $mixKeys)) {
    $arUrl['arPathSegments'] = static::getPathSegments($arUrl);
  }  
  //      
  $mixResult = arrays::get($arUrl, $mixKeys);
  //
  // DEBUG <<< ---
  // echo '$mixUrl'; echo '<br>'; print_r($mixUrl); echo '<hr>';
  // echo '$arUrl'; echo '<br>'; print_r($arUrl); echo '<hr>';
  // echo '$mixResult'; echo '<br>'; print_r($mixResult); echo '<hr>';
  // >>> DEBUG ---
  //
  return $mixResult;  
}
/**
 *
 */
public static function parse($mixUrl = null) {
  $arUrl = [];
  //
  if (is_null($mixUrl)) {
    $mixUrl = $_SERVER;
  }
  //
  if (is_array($mixUrl)) {
    $arUrl = static::parseServer($mixUrl);
  } else {
    $url = static::format($mixUrl);
    $arUrl = parse_url($url);
    $arUrl = arrays::get($arUrl, [
      'scheme' => 'protocol', 
      'host', 'port', 'path', 'query' => 'get', 
      'fragment' => 'hash'
    ]);
  }
  //
  // DEBUG <<< ---
  // echo '$arUrl'; echo '<br>'; print_r($arUrl); echo '<hr>';
  // >>> DEBUG ---
  //
  return $arUrl;                
} 
/**
 *
 */
static public function parseServer($arServer = []) {
  $arUrl = [];
  //
  $arUrl['protocol'] = (stripos($arServer['SERVER_PROTOCOL'], 'https') !== false) ? 'https' : 'http';
  if (stripos($arServer['REQUEST_SCHEME'], 'https') !== false) {
    $arUrl['protocol'] = 'https';
  }
  //
  $arUrl['host'] = $arServer['SERVER_NAME'];
  if ($arServer['SERVER_PORT'] != 80) {
    $arUrl['port'] = $arServer['SERVER_PORT'];
  }
  //
  $arPathTemp = explode('?', $arServer['REQUEST_URI']);
  $arUrl['path'] = $arPathTemp[0];
  $arUrl['get'] = (!empty($arPathTemp[1])) ? $arPathTemp[1] : '';
  //
  return $arUrl;
}
/**
 *
 */
static public function generate($arUrl = []) {
  $url = '';
  //
  if (!empty($arUrl['host'])) {
    if ($arUrl['protocol']) {
      $arUrl['protocol'] = 'http';
    }
    $url .= $arUrl['protocol'] . '://' . $arUrl['host'];
    if (!empty($arUrl['port'])) {
      $url .= ':' . $arUrl['port'];
    }
  }
  //
  if (!empty($arUrl['pathBase'])) {
    $url .= $arUrl['pathBase'];
  }
  if (!empty($arUrl['path'])) {
    $url .= $arUrl['path'];
  }
  //
  if (!empty($arUrl['arGet'])) {
    $arUrl['get'] = \http_build_query($arUrl['arGet'], 'arData');
  }
  if (!empty($arUrl['get'])) {
    $url .= '?' . $arUrl['get'];
  }
  if (!empty($arUrl['hash'])) {
    $url .= '#' . $hash;
  }
  //
  return $url;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getPathSegments($mixUrl = null) {
  $arPathSegments = [];
  //
  if (!is_array($mixUrl)) {
    $mixUrl = static::parse($mixUrl);
  }
  if (!empty($mixUrl['path'])) {  
    $arPathSegments = explode('/', trim($mixUrl['path'], '/'));
  }
  // 
  return $arPathSegments;  
}
/**
 *
 */
static public function getHostSegments($mixUrl = null) {
  $arHostSegments = [];
  //
  if (!is_array($mixUrl)) {
    $mixUrl = static::parse($mixUrl);
  }
  if (!empty($mixUrl['host'])) {
    $arHostSegments = explode('.', $mixUrl['host']);
  }
  //
  return $arHostSegments;  
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function format($path = '') {
  $pathResult = $path;
  //
  $pathResult = str_ireplace(['\\', '//'], '/', trim($pathResult));
  $pathResult = str_ireplace(':/', '://', $pathResult);
  //
  if (stripos($pathResult, '://') === false) {
    if (substr($pathResult, 0, 1) != '/') {
      $pathResult = '/' . $pathResult;
    }
  }
  //
  return $pathResult;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function redirect($url = '', $delay = 0) {
  if ($delay > 0) {
    header('Refresh: ' . $delay . '; URL=' . $url);
  } else { 
    header('Location: ' . $url);
  }
}
// =============================================================================
}
// =============================================================================
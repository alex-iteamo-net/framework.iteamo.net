<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================    
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 * 
 */  
class html {
// =============================================================================
/**
 *
 */
public static function getAttributes($arOptions = [], $arAttributesKeys = []) {
  $arAttributes = [];
  //   
  $arAttributes = arrays::getKeysValues($arOptions, $arAttributesKeys);
  $arAttributes = arrays::filter($arAttributes, function($value = null, $key = '') {
    return !is_null($value);
  });  
  //
  return $arAttributes;  
}
/**
 *
 */
public static function getAttributesString($arAttributes = []) {
  $strAttributes = '';
  //
  $strAttributesPairs = arrays::map($arAttributes, function($value = null, $key = '') {
    return $key . '="' . $value . '"';
  }); 
  $strAttributes = implode(' ', $strAttributesPairs);   
  //
  return $strAttributes;  
}
// -----------------------------------------------------------------------------
/**
 *
 */
public static function getInput($arOptions = []) {
  $strInput = '';
  //  
  $arOptions = array_replace(['value' => ''], $arOptions);
  $arAttributes = self::getAttributes($arOptions, ['name', 'type', 'checked', 'value', 'class', 'size', 'onChange', 'disabled']);
  $strAttributes = self::getAttributesString($arAttributes);
  //
  $strInput = '<input ' . $strAttributes . '>';
  //
  return $strInput;
}
/**
 *
 */
public static function getSelect($arOptions = []) {
  $strSelect = '';
  //    
  $arOptions = array_replace(['value' => '', 'arVariants' => []], $arOptions);
  $arAttributes = self::getAttributes($arOptions, ['name', 'class', 'onChange', 'disabled', 'multiple', 'size']);
  $strAttributes = self::getAttributesString($arAttributes);
  //
  $strSelect = '<select ' . $strAttributes . '>';
  //
  if (!is_array($arOptions['value'])) {
    $arOptions['value'] = [$arOptions['value']];
  }
  if (!empty($arOptions['defaultLabel'])) {
    $arOptions['arVariants'] = array_replace(['' => $arOptions['defaultLabel']], $arOptions['arVariants']);
  }
  $isAssociative = arrays::isAssociative($arOptions['arVariants']);
  foreach($arOptions['arVariants'] as $value => $label) {
    if (is_array($label)) {
      $strSelect .= '<optgroup label="' . $value . '">';
      $isAssociativeInner = arrays::isAssociative($label);
      foreach($label as $valueInner => $labelInner) {
        if (!$isAssociativeInner) {
          $valueInner = $labelInner;   
        }
        if (is_numeric($valueInner)) {
          $valueInner = (string)$valueInner;
        }                 
        $strSelect .= '<option value="' . $valueInner . '"' . ((in_array($valueInner, $arOptions['value'], !empty($arOptions['strict']))) ? ' selected' : '') . '>' . $labelInner . '</option>';  
      }
      $strSelect .= '</optgroup>';          
    } else {
      if (!$isAssociative) {
        $value = $label;   
      }    
      if (is_numeric($value)) {
        $value = (string)$value;
      }        
      $strSelect .= '<option value="' . $value . '"' . ((in_array($value, $arOptions['value'], !empty($arOptions['strict']))) ? ' selected' : '') . '>' . $label . '</option>';
    }
  }
  $strSelect .= '</select>';
  //
  // DEBUG <<< ---
  // echo '$arOptions'; echo '<br>'; print_r($arOptions); echo '<hr>';      
  // >>> DEBUG --- 
  //
  return $strSelect;
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
require_once(__dir__ . '/file.php');
// =============================================================================
/**
 *
 */ 
class curl {
// =============================================================================
/**
 *
 */
public static $arDefaultOptions = [
  'userAgent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.7) Gecko/20070914 Firefox/2.0.0.7',
  // 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.7) Gecko/20070914 Firefox/2.0.0.7'
  // 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
  // 'compression' => 'gzip',
  'timeout' => 25,
  // 'followLocation' => 1,
  'CURLINFO_HEADER_OUT' => 1,
  'CURLOPT_RETURNTRANSFER' => 1,
  //
  // 'CURLOPT_FAILONERROR' => 1,
  // 'CURLOPT_FOLLOWLOCATION' => 1,
  //
  'CURLOPT_SSL_VERIFYPEER' => false,
  'CURLOPT_SSL_VERIFYHOST' => false,
  //
  'CURLOPT_SAFE_UPLOAD' => false,
  'CURLOPT_VERBOSE' => true,
];
// -----------------------------------------------------------------------------
/**
 *
 */
public static function init() {
  $objCurl = null;
  //
  if (!$objCurl = \curl_init()) {
    throw new \exception('Could not initialize a cURL handle');    
  }  
  //
  return $objCurl;   
}
/**
 *
 */
public static setOptions($objCurl = null, $arOptions = []) {
  foreach($arOptions as $key => $value) {
    curl_setopt($objCurl, $key, $value);
    // eval('curl_setopt($objCurl, ' . $key . ', $value);');  
  }
  //
  return $objCurl;
} 
// -----------------------------------------------------------------------------
/**
 *
 */ 
public static function get($url = '', $arPost = [], $arCookies = [], $session = false, $arOptions = [], $sleep = 0, $arHeaders = [], $arProxy = []) {
  $strResponse = '';
  //
  $objCurl = self::init();    
  $arOptions['CURLOPT_URL'] = $url;
  //
  if (!empty($arProxy)) {
    if (!is_array($arProxy)) {
      $arProxy = ['address' => $arProxy];
    }    
    $arOptions['CURLOPT_PROXY'] = $arProxy['address'];
    if (!empty($arProxy['password'])) {      
      $arOptions['CURLOPT_PROXYUSERPWD'] = $arProxy['password'];
    }
    if (!empty($arProxy['type'])) {
      $arOptions['CURLOPT_PROXYTYPE'] = $arProxy['type'];  // CURLPROXY_HTTP / CURLPROXY_HTTP_1_0 / CURLPROXY_HTTPS / CURLPROXY_SOCKS4 / CURLPROXY_SOCKS5
    }
  }  
  if (!empty($arHeaders)) {
    $arOptions['CURLOPT_HTTPHEADER'] = $arHeaders;     
  }   
  //
  if (!empty($arCookie['file'])) {
    $arOptions['CURLOPT_COOKIEFILE'] = $arCookie['file'];
    $arOptions['CURLOPT_COOKIEJAR'] = $arCookie['file'];
  } else {
    if ($session) {
      $arCookies['PHPSESSID'] = session_id();    
    }
    if (!empty($arCookies)) {
      $arCookiesPairs = [];
      foreach($arCookies as $key => $value) {
        $arCookiesPairs[] = $key . '=' . $value;   
      } 
      $strCookies = implode('; ', $arCookiesPairs);
      $arOptions['CURLOPT_COOKIE'] = $strCookies;
    }   
  }            
  //
  if (!empty($arPost)) {
    $arOptions['CURLOPT_POST'] = true;
    if (!empty($arPost['file'])) {      
      if (class_exists('\CURLFile')) {
        $arPost['file'] = new \CURLFile($arPost['file']);
      } else {
        $arPost['file'] = '@' . $arPost['file'];
      } 
      $mixPost = $arPost;
    } else {
      $mixPost = \http_build_query($arPost);                  
    }       
    $arOptions['CURLOPT_POSTFIELDS'] = $mixPost;
  }
  //
  $arOptionsToSet = self::getOptionsToSet(self::$arDefaultOptions, $arOptions);
  self::setOptions($arOptionsToSet);  
  //
  if ($session) {
    session_write_close();
  }
  //
  $strResponse = curl_exec($objCurl);
  $status = curl_getinfo($objCurl, CURLINFO_HTTP_CODE);  
  //
  if ($session) {
    session_start();
  }  
  if (!empty($sleep)) {
    if ($sleep == 'random') {
      $sleep = rand(2, 7);
    }
    sleep($sleep);
  }
  //
  // DEBUG <<< ---
  // if (!empty($arProxy)) {
  // if (!empty($arPost['file'])) {
  // $arSentHeaders = curl_getinfo($objCurl, CURLINFO_HEADER_OUT);
  // echo '$arSentHeaders'; echo '<br>'; print_r($arSentHeaders); echo '<hr>';
  // echo '$arProxy'; echo '<br>'; print_r($arProxy); echo '<hr>';
  // echo '$strCookies'; echo '<br>'; print_r($strCookies); echo '<hr>';    
  // }        
  // >>> DEBUG ---
  //
  curl_close($objCurl);
  //
  return $strResponse;      
}
/**
 *
 */
public static function getCookies($strResponse = '') {
  $arCookies = [];
  //
  $regularExpression = '/Set-Cookie: (?<key>[^=;]+)=(?<value>[^=;]+)/isu';  
  $arMatches = [];
  preg_match_all($regularExpression, $strResponse, $arMatches, PREG_SET_ORDER);
  //
  foreach($arMatches as $arItem) {
    $arCookies[trim($arItem['key'])] = trim($arItem['value']);  
  }  
  //
  // DEBUG <<< ---          
  // echo '$strResponse'; echo '<br>'; print_r($strResponse); echo '<hr>';
  // echo '$arMatches'; echo '<br>'; print_r($arMatches); echo '<hr>';
  // echo '$arCookies'; echo '<br>'; print_r($arCookies); echo '<hr>';        
  // >>> DEBUG ---  
  //
  return $arCookies;
}
/**
 *
 */         
public static function downloadFile($url = '', $path = '') {
  $objCurl::init();
  //
  $objFile = file::open($path, 'w');
  file::lock($objFile);
  //
  curl_setopt($objCurl, CURLOPT_FILE, $objFile);
  curl_setopt($objCurl, CURLOPT_HEADER, 0);
  curl_setopt($objCurl, CURLOPT_TIMEOUT, curl::$timeOut);
  curl_exec($objCurl);
  if (curl_error($objCurl)) {
    return false;
  }
  file::close($objFile);
  curl_close($objCurl);
  //
  return true;
}
// -----------------------------------------------------------------------------
/**
 *
 */
protected static function getOptionsToSet($arDefaultOptions = [], $arOptions = []) {
  $arOptionsToSet = array_replace($arDefaultOptions, $arOptions);
  //
  $arMapping = [
    'withHeader' => 'CURLOPT_HEADER',
    'userAgent' => 'CURLOPT_USERAGENT', 
    'compression' => 'CURLOPT_ENCODING', 
    'timeout' => 'CURLOPT_TIMEOUT',
    'followLocation' => 'CURLOPT_FOLLOWLOCATION',  
  ];
  //
  $arOptionsToSet = arrays::changeKeys($arOptionsToSet, $arMapping);
  //
  // DEBUG <<< ---
  // echo '$arOptionsToSet'; echo '<br>'; print_r($arOptionsToSet); echo '<hr>';    
  // >>> DEBUG ---
  //
  return $arOptionsToSet; 
}  
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/file.php');
require_once(__dir__ . '/encoding.php');
// =============================================================================
/**
 *
 */ 
class mails {
// =============================================================================
/**
 *
 */     
public static function send(
  $arFrom = ['mail' => '', 'name' => ''],
  $arTo = ['mail' => '', 'name' => ''],
  $subject = '', 
  $body = '',                       
  $arOptions = [
    'replyTo' => '', 
    'type' => 'plain', 
    'encodingFrom' => 'UTF-8', 
    'encodingTo' => 'UTF-8'
  ],
  $arFiles = []
) {
  $result = false;
  //  
  $boundary = '--' . md5(uniqid(time()));      
  //
  $from = '';
  if (!empty($arFrom['mail'])) {
    $from = '<' . $arFrom['mail'] . '>';
  }
  if (!empty($arFrom['name'])) {
    $from = self::encodeHeader($arFrom['name'], $arOptions['encodingFrom'], $arOptions['encodingTo']) . ' ' . $from;  
  }
  $to = '<' . $arTo['mail'] . '>';  
  if (!empty($arTo['name'])) {
    $to = self::encodeHeader($arTo['name'], $arOptions['encodingFrom'], $arOptions['encodingTo']) . ' ' . $to;  
  } 
  //      
  if($arOptions['encodingFrom'] != $arOptions['encodingTo']) {
    $subject = self::encodeHeader($subject, $arOptions['encodingFrom'], $arOptions['encodingTo']);
    $body = encoding::get($body, $arOptions['encodingFrom'], $arOptions['encodingTo']);    
  }
  //
  $headers = "From: $from\r\n"; 
  $headers .= "Return-path: " . $arFrom['mail'] . "\r\n";         
  if ($arOptions['replyTo']) {
    $headers .= "Reply-To: <" . $arOptions['replyTo'] . ">\r\n";
  }  
  $headers .= "Mime-Version: 1.0\r\n";   
  $headers .= "Content-Type: multipart/mixed; boundary=\"" . $boundary . "\"\r\n";  
  //    
  $content = '';
  $content .= '--' . $boundary . "\r\n";  
  $content .= "Content-type: text/" . $arOptions['type'] . "; charset=" . $arOptions['encodingTo'] . "\r\n";
  $content .= "Content-Transfer-Encoding: quoted-printable\r\n\r\n";    
  $content .= $body . "\r\n\r\n";
  $fileHeaders = self::getFileHeaders($arFiles);
  $content .= $fileHeaders . '--' . $boundary . "--\r\n";
  //
  $result = mail($to, $subject, $content, $headers);
  //
  // DEBUG <<< ---
  // echo '$to'; echo '<br>'; print_r($to); echo '<hr>';
  // echo '$subject'; echo '<br>'; print_r($subject); echo '<hr>';    
  // echo '$content'; echo '<br>'; print_r($content); echo '<hr>';
  // echo '$headers'; echo '<br>'; print_r($headers); echo '<hr>';
  // echo '$result'; echo '<br>'; print_r($result); echo '<hr>';
  // >>> DEBUG ---
  //    
  return $result; 
}
// -----------------------------------------------------------------------------
static protected function getFileHeaders($arFiles = []) {
  $fileHeaders = '';
  //
  foreach($arFiles as $arFile) {    
    $arFile['content'] = file::readBinary($arFile['path']);
    if (!empty($arFile['content'])) {      
      $fileHeaders .= '--' . $boundary . "\r\n";
      $fileHeaders .= "Content-Type: application/octet-stream\r\n";
      $fileHeaders .= "Content-Transfer-Encoding: base64\r\n";
      $fileHeaders .= "Content-Disposition: attachment; filename=\"" . $arFile['name'] . "\"\r\n\r\n";
      $fileHeaders .= chunk_split(base64_encode($arFile['content'])) . "\r\n";     
    }
  }  
  //
  return $fileHeaders;
} 
// -----------------------------------------------------------------------------
/**
 *
 */ 
static public function encodeHeader($text = '', $encodingFrom = '', $encodingTo = '') {
  $strResult = '';
  //
  if($encodingFrom != $encodingTo) {
    $strResult = encoding::get($text, $encodingFrom, $encodingTo);
  }
  $strResult = '=?' . $encodingTo . '?B?' . base64_encode($strResult) . '?='; 
  //
  // DEBUG <<< ---
  // echo '$strResult'; echo '<br>'; print_r($strResult); echo '<hr>';
  // >>> DEBUG ---
  //  
  return $strResult;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function parse($strMails = '', $mode = '') { 
  $arMails = [];
  //
  if (stripos($strMails, '@')) {
    $arMailsTemp = [];
    preg_match_all('/\b([a-z0-9._-]+@[a-z0-9.-]+)\b/isu', $strMails, $arMailsTemp);
    if (!empty($arMailsTemp[0])) {
      $arMailsTemp = $arMailsTemp[0];
      foreach($arMailsTemp as $mail) {
        if ($mode == 'returnParts') {
          $arMail = explode('@', $mail);
          $arMails[] = ['user' => $arMail[0], 'domain' => $arMail[1]];    
        } else {
          $arMails[] = $mail;
        }  
      }
      $arMails = array_unique($arMails);
    }
  }
  //
  // DEBUG <<<
  // echo '$strMails'; echo '<br>'; print_r($strMails); echo '<hr>';
  // echo '$arMails'; echo '<br>'; print_r($arMails); echo '<hr>';
  // >>> DEBUG   
  //
  return $arMails; 
}  
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 * 
 */ 
class arrays {
// =============================================================================
/**
 *
 */
static public function isAssociative($arArray = []) {
  $result = false;
  //
  $arKeys = array_keys($arArray);
  foreach($arKeys as $key) {
    if (isset($previousKey)) {
      if ($key !== $previousKey + 1) {
        $result = true; break;
      }
    } elseif ($key !== 0) {
      $result = true; break;
    }
    $previousKey = $key;
  }
  //
  // DEBUG <<< ---
  // echo '$arArray'; echo '<br>'; print_r($arArray); echo '<hr>';
  // echo '$result'; echo '<br>'; print_r($result); echo '<hr>';     
  // >>> DEBUG ---
  //
  return $result; 
}
/**
 *
 */
static public function isPlain($arArray = []) {
  $result = true;
  //
  foreach($arArray as $key => $value) {
    if (is_array($value)) {
      $result = false; break;
    }
  }
  //
  return $result; 
}
/**
 *
 */ 
static public function getMaxDepth($arItems = []) {  
  $depth = 0;
  //
  $arQueue = $arItems;
  $arQueue2 = [];
  while(($arItem = array_shift($arQueue)) || !empty($arQueue2)) {
    if (!empty($arItem)) {
      if (is_array($arItem)) {
        while($arItemInner = array_shift($arItem)) {
          $arQueue2[] = $arItemInner;
        }
      }
    } elseif (!empty($arQueue2)) {
      $arQueue = $arQueue2;
      $arQueue2 = [];
      $depth++; 
    }         
  }
  //
  // DEBUG <<< ---  
  // echo '$arItems'; echo '<br>'; print_r($arItems); echo '<hr>';
  // >>> DEBUG ---
  //
  return $depth;   
} 
// -----------------------------------------------------------------------------
/**
 *
 */
static public function filter(&$arItem = [], callable $mixCallable = null, $flag = ARRAY_FILTER_USE_BOTH) {
  $arResult = array_filter($arItem, $mixCallable, $flag);
  //
  return $arResult;
}
/**
 *
 */
static public function filterRecursive($array = [], callable $callback) { 
  foreach ($array as $key => $value) { 
    if (is_array($value)) { 
      $array[$key] = self::filterRecursive($value, $callback); 
    } else { 
      if (!$callback($value, $key)) { 
        unset($array[$key]); 
      } 
    } 
  }   
  return $array; 
}
/**
 *
 */
static public function map(&$arItem = [], callable $mixCallable = null) {
  $arResult = array_map($mixCallable, $arItem, array_keys($arItem));
  //
  return $arResult;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getKeyValue(&$arItem = [], $key = '') {
  $value = null;
  //  
  if (stripos($key, '[') !== false) {
    eval('$value = $arItem' . $key . ';');    
  } else {
    $value = (isset($arItem[$key])) ? $arItem[$key] : null;
  }
  //
  return $value;
}
/**
 *
 */
static public function setKeyValue(&$arItem = [], $key = '', $value = '') {
  if (stripos($key, '[') !== false) {
    eval('$arItem' . $key . ' = "' . $value . '";');
  } else {    
    $arItem[$key] = $value;
  }
  //
  return $arItem;
}
/**
 *
 */
static public function deleteKey(&$arItem = [], $key = '') {
  if (stripos($key, '[') !== false) {
    eval('unset($arItem' . $key . ');');
  } else {    
    if (array_key_exists($key, $arItem)) {    
      unset($arItem[$key]);
    }
  }
  //
  return $arItem;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getFirst($arItems = []) {
  $value = reset($arItems);
  //
  return $value;
}
/**
 *
 */
static public function getLast($arItems = []) {
  $value = end($arItems);
  //
  return $value;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function pullKeyValue(&$arItem = [], $key = '') {
  $value = self::getKeyValue($arItems, $key);
  self::deleteKey($arItem, $key);  
  //
  return $value;
}
/**
 *
 */
static public function pullFirst(&$arItems = []) {
  $value = array_shift($arItems);
  //
  return $value;
}
/**
 *
 */
static public function pullLast(&$arItems = []) {
  $value = array_pop($arItems);
  //
  return $value;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getKeysValues($arItem = [], $arKeysMap = []) {
  $arResult = [];
  //              
  foreach($arKeysMap as $keyFrom => $keyTo) {        
    if (is_int($keyFrom)) {
      $keyFrom = $keyTo;   
    }
    $value = static::getKeyValue($arItem, $keyFrom);
    if (!is_null($value)) {          
      static::setKeyValue($arResult, $keyTo, $value);
    }    
  }
  //
  return $arResult;
}
/**
 *
 */
static public function changeKeys($arInput = [], $arKeys = []) {
  $arResult = $arInput;
  //              
  foreach($arKeys as $keyFrom => $keyTo) {                             
    $value = static::getKeyValue($arInput, $keyFrom);
    if (!is_null($value)) {          
      static::deleteKey($arResult, $keyFrom);  
      static::setKeyValue($arResult, $keyTo, $value);
    }
  } 
  //
  return $arResult;
}
/**
 *
 */
static public function deleteKeys($arItem = [], $arKeys = []) {
  foreach($arKeys as $key) {
    static::deleteKey($arItem, $key);
  }
  //
  return $arItem;   
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function get(&$arItem = [], $mixKeys = null) {
  $mixResult = $arItem;
  //
  if (!empty($mixKeys)) {    
    if (is_array($mixKeys)) {      
      $mixResult = static::getKeysValues($arItem, $arKeys = $mixKeys);
    } else {
      $mixResult = static::getKeyValue($arItem, $key = $mixKeys);
    }
  }
  //
  return $mixResult;  
} 
/**
 *
 */
static public function set(&$arItem = [], $mixKey = null, $mixValue = null) {
  $arItemResult = $arItem;
  //
  if (!empty($mixKey)) {    
    if (is_array($mixKey)) {      
      if ($mixValue == 'recursive') {
        $arItemResult = static::mergeUpdate($arItem, $mixKey, 'recursive');
      } else {
        $arItemResult = static::mergeUpdate($arItem, $mixKey);
      }
    } else {
      static::setKeyValue($arItemResult, $mixKey, $mixValue);
    }
  }
  //
  return $arItemResult;  
} 
/**
 *
 */
static public function in($mixKeysToFind = null, $mixKeys = null) {
  $result = true;
  //
  if (!empty($mixKeys)) {
    $arKeys = (is_array($mixKeys)) ? $mixKeys : [$mixKeys];
    if (is_array($mixKeysToFind)) {
      $result = (count($mixKeysToFind) == count(array_intersect($mixKeysToFind, $arKeys)));  
    } else {
      $result = in_array($mixKeysToFind, $arKeys);
    }    
  }
  //
  return $result; 
}
// -----------------------------------------------------------------------------
/**     
 *     
 */
static public function combine($arKeys = [], $arValues = []) {
  $arResult = [];
  //              
  $arResult = array_combine($arKeys, $arValues);
  //
  // DEBUG <<< ---
  // echo '$arKeys'; echo '<br>'; print_r($arKeys); echo '<hr>';
  // echo '$arValues'; echo '<br>'; print_r($arValues); echo '<hr>';
  // echo '$arResult'; echo '<br>'; print_r($arResult); echo '<hr>';  
  // >>> DEBUG ---
  //
  return $arResult;    
}
/**
 *
 */
static public function unique($arValues = []) {
  $arResult = [];
  //              
  $arResult = array_unique($arValues);  
  //
  // DEBUG <<< ---
  // echo '$arValues'; echo '<br>'; print_r($arValues); echo '<hr>';
  // echo '$arResult'; echo '<br>'; print_r($arResult); echo '<hr>';  
  // >>> DEBUG ---
  //
  return $arResult;     
}
/**
 *
 */
static public function getValues($arItem = [], $mixOptions = '') {
  $arValues = [];
  //
  if ($mixOptions == 'recursive') {
    foreach($arItem as $value) {
      if (is_array($value)) {
        $arValues = array_merge($arValues, self::getValues($value, $mixOptions));
      } else {
        $arValues[] = $value;
      }
    }
  } else {
    $arValues = array_values($arInput);  
  }
  //
  return $arValues;
}
/**
 *
 */
static public function mergeUpdate($arItem = [], $arUpdate = [], $mixOptions = '') {
  if ($mixOptions == 'recursive') {
    $arResult = array_replace_recursive($arItem, $arUpdate);
  } else {
    $arResult = array_replace($arItem, $arUpdate);
  }
  //
  return $arResult;
}  
/**
 *
 */
public static function insertAfter($arItem = [], $keyPrevious = '', $key = '', $value = null) {
  $arItemResult = [];
  //
  foreach($arItem as $keyInner => $valueInner) {
    $arItemResult[$keyInner] = $valueInner;
    if ($keyInner == $keyPrevious) {
      $arItemResult[$key] = $value;  
    }  
  }
  //
  return $arItemResult;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function unfoldKeys($arItem = []) {
  $arItemResult = [];
  //
  foreach($arItem as $key => $value) {
    if (stripos($key, '[') !== false) {
      $fullPath = '[' . substr_replace($key, '][', stripos($key, '['), 1);
      eval("\$arItemResult" . $fullPath . " = \$value;");
    } else $arItemResult[$key] = $value;
  }
  //
  return $arItemResult;
}
/**
 *
 */
static public function foldKeys($arItems = [], $separator = ':/:', $prefix = '') {
  $arResult = [];
  //
  foreach($arItems as $key => $value) {
    if (!empty($prefix)) {
      $prefixIteration = $prefix . $separator . $key;
    } else $prefixIteration = $key;
    //
    if (is_array($value)) {
      $arResult = array_merge($arResult, self::foldKeys($value, $separator, $prefixIteration));
    } else $arResult[$prefixIteration] = $value;
  }
  //
  return $arResult;
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/callables.php');
// =============================================================================
/**
 * 
 */   
class cache {
// =============================================================================
/**
 *
 */
static public function getStatic($key = '', $mixCallable = null, $arParams = []) {
  $arResult = null;
  //  
  static $arCache = [];
  $keyPrepared = static::prepareKey($key);
  if (!array_key_exists($keyPrepared, $arCache)) {
    $arCache[$keyPrepared] = callables::call($mixCallable, $arParams);
  }
  $arResult = $arCache[$keyPrepared];
  //
  return $arResult;  
}
// -----------------------------------------------------------------------------
/**
 *
 */
static private function prepareKey($key = '', $mixCallable = null) {
  $keyPrepared = $key;
  //
  $callableName = callables::getName($mixCallable);
  if (!empty($mixCallable)) {
    $keyPrepared = implode('/', [$callableName, $keyPrepared]);   
  } 
  //
  return $keyPrepared; 
}
// =============================================================================
}
// =============================================================================
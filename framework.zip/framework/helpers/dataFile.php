<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/file.php');
// =============================================================================
/**
 *
 */
class dataFile {
// =============================================================================
/**
 *
 */ 
static public function write($path = '', $arData = []) {
  $result = false;
  //
  $strData = var_export($arData, true);
  //  
  $strData = str_ireplace('array (', '[', $strData);
  $strData = str_ireplace(')', ']', $strData);
  $strData = preg_replace('/\>[^\[\]]+\[/isu', '> [', $strData);
  $strData = '<? return ' . $strData . ';';
  //  
  $result = file::write($path, $strData, 'w+');
  //
  // DEBUG <<< ---
  // echo '$path'; echo '<br>'; print_r($path); echo '<hr>';
  // >>> DEBUG ---
  //  
  return $result;  
}
/**
 *
 */
static public function read($path = '') {
  $arData = null;
  //
  if (file::exists($path)) {
    $arData = require($path);   
  }
  //
  // DEBUG <<< ---
  // echo '$arFile'; echo '<br>'; print_r($arFile); echo '<hr>';  
  // >>> DEBUG ---
  //  
  return $arData;
} 
// =============================================================================
}
// =============================================================================
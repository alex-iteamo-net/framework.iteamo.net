<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 * 
 */  
class session {
// =============================================================================
/**
 *
 */
public static function start() {
  if (!self::isStarted()) {
    session_start();
  }
}
/**
 *
 */
public static function getId() {
  $id = session_id();
  //
  return $id;
}
/**
 *
 */
public static function isStarted() {
  $isStarted = (!empty(self::getId()));
  //
  return $isStarted;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public static function set($key = '', $value = '', $start = true) {  
  if ($start) {
    self::start();
  }
  $_SESSION = arrays::set($_SESSION, $key, $value);
}
/**
 *
 */
public static function get($mixKeys = null, $start = true) {
  $mixResult = null;
  //
  if ($start) {
    self::start();
  }
  if (isset($_SESSION)) {
    $mixResult = arrays::get($_SESSION, $mixKeys);
  }
  //
  return $mixResult;
}
// =============================================================================
}
// =============================================================================
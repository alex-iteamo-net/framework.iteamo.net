<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/file.php');
// =============================================================================
/**
 *
 */
class log {
// =============================================================================
/**
 *
 */ 
public static function write($path = '', $mixData = null) {
  $result = false;
  //
  $arSettings = [
    'separator' => chr(13) . '// =========================================================================' . chr(13),
  ];  
  //
  if (!is_string($mixData)) {
    $arDataPairs = [];
    foreach($mixData as $key => $value) {
      if (is_array($value) || is_object($value)) {
        $value = var_export($value, $return = true);
      }
      $arDataPairs[] = "$key = $value";
    }
    $strData = implode(chr(13), $arDataPairs);
  } else {
    $strData = $mixData; 
  }  
  //
  $strDataToWrite = $strData . $arSettings['separator'];
  file::write($path, $strDataToWrite, 'a+');
  //
  return $result;  
}
// =============================================================================
}
// =============================================================================
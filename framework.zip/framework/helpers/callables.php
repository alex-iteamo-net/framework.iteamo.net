<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 * 
 */   
class callables {
// =============================================================================
/**
 *
 */
static public function is(callable $mixCallable = null) {
  $result = is_callable($mixCallable);
  //  
  return $result;  
}
/**
 *
 */
static public function call(callable $mixCallable = null, $arParams = []) {
  $arResult = null;
  //
  $arResult = call_user_func_array($mixCallable, $arParams);
  //  
  return $arResult;  
}
/**
 *
 */
static public function getName(callable $mixCallable = null) {
  $name = null;
  //  
  if (is_string($mixCallable)) {
    $name = trim($mixCallable);
  } else if (is_array($mixCallable)) {
    if (is_object($mixCallable[0])) {
      $name = sprintf("%s::%s", \get_class($mixCallable[0]), trim($mixCallable[1]));      
    } else {
      $name = sprintf("%s::%s", trim($mixCallable[0]), trim($mixCallable[1]));
    }
  } else if ($mixCallable instanceof \closure) 
    return 'closure';
  }
  //
  return $name;  
}
// =============================================================================
}
// =============================================================================
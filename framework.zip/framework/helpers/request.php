<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/url.php');
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 *
 */   
class request {
// =============================================================================
/**
 *
 */
static public function get($mixKeys = null) {
  $mixResult = [];
  //
  static $arRequest = [];
  if (empty($arRequest)) {
    $arRequest = [
      'arGet' => $_GET,
      'arPost' => $_POST,
      'arGetPost' => array_replace($_REQUEST, $_POST),
      'arServer' => $_SERVER,
      'arCookies' => $_COOKIE,
      'arFiles' => static::getFiles($_FILES),
      'arHeaders' => static::getHeaders(),
    ];
    $arRequest['arUrl'] = url::parseServer($arRequest['arServer']);    
  }
  $mixResult = arrays::get($arRequest, $mixKeys);  
  // 
  return $mixResult;
}
/**
 *
 */
static private function getFiles($arFiles = []) {
  $arFilesResult = [];
  //  
  if (is_array($arFiles)) {
    foreach($arFiles as $fieldKey => $arFile) {
      if (!empty($arFile['name'])) {
        $arFileResult = [
          'name' => $arFile['name'],
          'type' => $arFile['type'],
          'path' => $arFile['tmp_name'],
          'size' => $arFile['size'], 
        ];
        $arFilesResult[$fieldKey] = $arFileResult;
      }
    }  
  }
  //
  return $arFilesResult;
}
/**
 *
 */
static public function getHeaders() {
  $arHeaders = getAllHeaders();
  //
  return $arHeaders;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getIp() {
  $ip = null;
  //
  $arServer = self::get('arServer');
  $ip = $arServer['REMOTE_ADDR'];
  if (!empty($arServer['HTTP_CLIENT_IP'])) {
    $ip = $arServer['HTTP_CLIENT_IP'];
  } elseif (!empty($arServer['HTTP_X_FORWARDED_FOR'])) {
    $ip = $arServer['HTTP_X_FORWARDED_FOR'];
  };
  //
  return $ip;
}
// =============================================================================
}
// =============================================================================
<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 *
 */
class file {
// =============================================================================
/**
 *
 */
static public function open($path = '', $mode = 'r') {
  $objFile = fopen($path, $mode);
  //
  return $objFile;
}
/**
 *
 */
static public function close($objFile = null) {
  $result = fclose($objFile);
  //
  return $result;
}
/**
 *
 */
static public function lock($objFile = null, $mode = LOCK_EX, $attemptsCount = 5) {
  $result = false;
  //
  $attemptsCounter = 1;
  while ($attemptsCounter <= $attemptsCount) {
    if (flock($objFile, $mode)) {
      $result = true; break;
    } else {
      usleep(10);
      $attemptsCounter++;
    }
  }
  //
  return $result;
}
/**
 *
 */
static public function unlock($objFile) {
  fflush($objFile);
  $result = flock($objFile, LOCK_UN);
  //
  return $result;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function read($path = '') {
  $arData = null;
  //
  if (self::exists($path)) {
    $arData = file($path);
  }
  return $arData;
}
/**
 *
 */
static public function readInLine($path = '') {
  $strData = null;
  //
  $arLines = self::read($path);
  if (!is_null($arLines)) {
    $strData = join($arLines);
    $strData = trim($strData);
  }
  //
  return $strData;
}
/**
 *
 */
static public function readBinary($path = '', $length = null) {
  $strData = null;
  //
  $objFile = self::open($path, $mode);
  if ($objFile) {    
    if (is_null($length)) {
      $length = filesize($path); 
    }
    $strData = fread($objFile, $length);
    self::close($objFile);    
  }
  //
  return $strData;
}
/**
 *
 */
static public function write($path = '', $strData = '', $mode = 'w+') {
  $result = false;
  //
  $objFile = self::open($path, $mode);
  if ($objFile) {
    if (self::lock($objFile)) {
      $result = fwrite($objFile, $strData);
      self::unlock($objFile);
      self::close($objFile);
    }
  }
  //
  return $result;
}
// -----------------------------------------------------------------------------
/**
 *
 */ 
static public function getInfo($path = '', $mixKeys = null) {
  $mixResult = null;
  //
  if (self::exists($path)) {
    $arPathInfo = pathinfo($path);
    $arInfo = [
      'fileName' => $arPathInfo['filename'],
      'directory' => $arPathInfo['dirname'],    
      'extension' => $arPathInfo['extension'], 
    ];
    $arInfo['path'] = $arInfo['directory'] . $arInfo['fileName']; 
    //    
    if (arrays::in('size', $mixKeys)) {    
      $arInfo['size'] = filesize($arInfo['path']);
    }
    if (arrays::in('arDateTime[creation]', $mixKeys)) {
      $arInfo['arDateTime[creation]'] = filectime($arInfo['path']);
    }
    if (arrays::in('arDateTime[modification]', $mixKeys)) {    
      $arInfo['arDateTime[modification]'] = filemtime($arInfo['path']);
    }      
    //  
    $mixResult = arrays::get($arInfo, $mixKeys);
  }
  //
  return $mixResult; 
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function getDirectoryFiles($directory = '', $withDirectories = true, $recursive = false, $arExtensions = []) {
  $arFiles = [];
  //
  if (!file_exists($directory)) {     
    $objDirectory = opendir($directory);
    while (false !== ($file = readdir($objDirectory))) {
      if ( $file != "." && $file != ".." && !empty($file)) {
        $path = $directory . '/' . $file;
        if (!is_dir($path)) {
          if (!empty($arExtensions)) {
            $extension = pathinfo($path, PATHINFO_EXTENSION);
            if (in_array($extension, $arExtensions)) {
              $arFiles[] = $path;  
            }  
          } else {
            $arFiles[] = $path; 
          }        
        } else {
          if ($withDirs) {
            $arFiles[] = $path;
          }
          if ($recursive) {
            $arFilesInner = self::getDirectoryFiles($path, $withDirs, $recursive = true, $arExtensions);
            $arFiles = array_merge($arFiles, $arFilesInner); 
          }            
        }
      }
    }
    closedir($objDirectory);
  }  
  //
  return $arFiles;
}
/**
 *
 */
public function getDirectoriesTree($directory = '', $arExclude = [], $limit = 100000) {
  $arDirectoriesTree = array();
  //
  $arStack = [];
  $arStack[] = $directory;
  $step = 1;  
  //
  while (!empty($arStack)) {
    $arDirectory['path'] = array_pop($arStack);
    $arDirectory['arChildren'] = [];
    //
    $objDirectory = opendir($arDirectory['path'] . '/');
    while (false !== ($arChildDirectory['name'] = readdir($objDirectory))) {
      if (is_dir($arDirectory['path'] . '/' . $arChildDirectory['name']) && (!in_array($arChildDirectory['name'], ['..', '.']))) {
        $arChildDirectory['path'] = $arDirectory['path'] . '/' . $arChildDirectory['name'];
        $boolInclude = true;
        foreach($arExclude as $excludeItem) {
          if (stripos($arChildDirectory['path'], $excludeItem) !== false) {
            $boolInclude = false;
            break;
          } 
        }
        if ($boolInclude) {
          $arDirectory['arChildren'][$arChildDirectory['path']] = $arChildDirectory['path'];
          $arStack = array_merge($arStack, array_reverse($arDirectory['arChildren']));
        }       
      }
    }
    closedir($objDirectory);
    $arDirectoriesTree[] = $arDirectory['path'];
    $step++;    
    if ($step > $limit) break;  
  }
  //
  return $arDirectoriesTree;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function exists($path = '') {
  $result = file_exists($path);
  //
  return $result;
}
/**
 *
 */
static public function createDirectory($path = '', $rights = 0777, $recursive = true) {
  $result = true;
  //
  if (!file_exists($path)) {
    $result = mkdir($path, $rights, $recursive);
  }
  //
  return $result;
}
/**
 *
 */
static public function copy($pathFrom = '', $pathTo = '', $createDirectory = false) {
  $result = true;
  //
  if ($createDirectory) {
    $result = self::createDirectory(dirname($pathTo));
  }
  if ($result) {
    $result = copy($pathFrom, $pathTo);
  }
  //
  return $result;
} 
/**
 *
 */ 
static public function move($pathFrom = '', $pathTo = '') {
  $result = false;
  //
  if (self::copy($pathFrom, $pathTo)) {
    $result = self::delete($pathFrom);
  }
  //
  return $result;
}     
/**
 *
 */ 
static public function delete($path = '') {
  self::setRights($path, 0777);
  $result = unlink($path); 
  //
  return $result; 
}
/**
 *
 */ 
static public function setRights($path = '', $rights = 0777) {
  $result = @chmod($path, $rights);
  //
  return $result;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function identical($pathLeft = '', $pathRight = '') {
  $result = true;
  //
  $arCheckMethods = ['filetype', 'filesize', 'md5_file'];
  foreach($arCheckMethods as $method) {
    if ($method($pathLeft) !== $method($pathRight)) {
      $result = false; break;    
    }       
  } 
  //
  return $result; 
} 
// =============================================================================
}
// =============================================================================
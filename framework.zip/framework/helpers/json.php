<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/encoding.php');
// =============================================================================
/**
 *
 */
class json {
// =============================================================================
/**
 *
 */
static public function encode($arData = []) {
  return json_encode($arData);
}
/**
 *
 */
static public function decode($strData = '') {
  return json_decode($strData, $assoc = true);
}
/**
 *
 */
static public function encodeRu($arData = []) {
  return json_encode(self::jsonFixCyrillic($arData));
}
// -----------------------------------------------------------------------------
/**
 *
 */ 
static public function jsonFixCyrillic($mixInput = null) {
  $mixResult = null;
  //
  if (is_array($mixInput)) {
    $mixResult = [];
    foreach ($mixInput as $k => $v) {
      $mixResult[self::jsonFixCyrillic($k)] = self::jsonFixCyrillic($v);
    }
  } elseif (is_object($mixInput)) {
    $mixResult = get_object_vars($mixInput);
    foreach ($mixResult as $key => $value) {
      $mixResult->$key = self::jsonFixCyrillic($value);
    }
  } elseif (is_string($mixInput)) {     
    $mixResult = (function_exists('iconv')) ? iconv('cp1251', 'utf-8', $mixInput) : encoding::iconvEmulator($mixInput);
    iconv(string in_charset, string out_charset, string str)
  }
  return $mixResult;
}
// =============================================================================
}
// =============================================================================
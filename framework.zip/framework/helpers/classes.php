<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 * 
 */   
class classes {
// =============================================================================
/**
 *
 */
static public function getInfo($class = '', $mixKeys = null) {
  $arResult = null;
  //
  $arInfo['class'] = $class;  
  $arInfo['parentClass'] = \get_parent_class($arInfo['class']);
  //
  $objClass = new \ReflectionClass($arInfo['class']);
  $arInfo['path'] = str_ireplace('\\', '/', $objClass->getFileName());
  //
  if (arrays::in('namespace', $mixKeys)) {
    $arInfo['namespace'] = $objClass->getNamespaceName();
  }
  //         
  $arResult = arrays::get($arInfo, $mixKeys);
  //
  return $arResult;  
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function format($key = '') {
  $keyResult = '';
  //   
  $keyResult = rtrim(str_ireplace(['\\', '/'], '\\', trim($key)), '\\');   
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';    
  // echo '$keyResult'; echo '<br>'; print_r($keyResult); echo '<hr>'; 
  // >>> DEBUG ---  
  //  
  return $keyResult; 
}
// =============================================================================
}
// =============================================================================
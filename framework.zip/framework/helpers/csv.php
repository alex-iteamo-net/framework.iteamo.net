<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/file.php');
// =============================================================================
/**
 *
 */  
class csv {
// =============================================================================
/**
 *
 */
static public function readLine($objFile = null, $delimiter = ';', $enclosure = '"', $length = 5000) {
  $arLine = \fgetcsv($objFile, $length, $delimiter, $enclosure);
  //
  if (is_array($arLine)) {
    foreach($arLine as $key => $fieldValue) {
      $arLine[$key] = $fieldValue;
    }
  }
  //
  return $arLine;
}
/**
 *
 */
static public function writeLine($objFile = null, $arLine = [], $delimiter = ';', $enclosure = '"') {
  $result = false;
  //
  $result = \fputcsv($objFile, $arLine, $delimiter, $enclosure);  
  //
  return $result;
}
// =============================================================================
}
// =============================================================================
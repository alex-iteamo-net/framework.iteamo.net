<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
require_once(__dir__ . '/arrays.php');
// =============================================================================
/**
 * 
 */ 
class lists {
// =============================================================================
/**
 *
 */
static public function column($arList = [], $key = '', $indexKey = null) {
  $arListResult = [];
  //
  $arListResult = array_column($arList, $key, $indexKey); 
  //  
  return $arListResult;
}
/**
 *
 */
static public function map(&$arItem = [], callable $mixCallable = null) {
  $arResult = arrays::map($arItem, $mixCallable);
  //
  return $arResult;
}
/**
 *
 */
static public function filter(&$arItem = [], callable $mixCallable = null) {
  $arResult = arrays::filter($arItem, $mixCallable);
  //
  return $arResult;
}
// -----------------------------------------------------------------------------
/**     
 *     
 */
static public function getKeysValues(&$arList = [], $mixKey = null, $indexKey = '') {
  $arKeyValues = [];
  //  
  foreach ($arList as $itemKey => $arItem) {
    $value = arrays::get($arItem, $mixKey);
    if (!empty($indexKey)) {
      if ($indexKey == 'keepKeys') {
        $arKeyValues[$itemKey] = $value;
      } else {
        $resultKeyValue = arrays::getKeyValue($arItem, $indexKey); 
        $arKeyValues[$resultKeyValue] = $value;
      }
    } else {
      $arKeyValues[] = $value;
    }
  }
  //
  return $arKeyValues;        
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function group(&$arList = [], $groupKey = '') {
  $arListResult = [];
  //
  foreach($arList as $indexKey => $arItem) {
    $group = isset($arItem[$groupKey]) ? $arItem[$groupKey] : null;
    $arListResult[$group][$indexKey] = $arItem;
  }
  //
  return $arListResult;   
} 
// -----------------------------------------------------------------------------
/**
 *
 */
static public function addToEvery($arList = [], $arAddition = []) {
  $arListResult = [];
  //
  foreach($arList as $key => $arItem) {
    $arListResult[$key] = arrays::mergeUpdate($arItem, $arAddition, 'recursive');
  }
  //  
  return $arListResult;
}
// =============================================================================
}
// =============================================================================
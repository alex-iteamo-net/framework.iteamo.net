<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 *
 */  
class text {
// =============================================================================
/**
 *
 */
static public function getArray($text = '', $separator = null) {
  $arItems = [];
  //
  if (!empty($separator)) {
    $textTemp = str_ireplace($separator, '||', $text);
    $arText = explode('||', $textTemp);    
    foreach($arText as $item) {
      $item = trim($item);
      if (!empty($item)) {
        $arItems[] = $item;
      }
    }
  }
  //
  return $arItems;
}
// -----------------------------------------------------------------------------
/**
 *
 */   
static public function upperFirstChar($text = '') {
  $textResult = mb_strtoupper($text);    
  //
  return $textResult;
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function translit($text = '') {
  $result = $text;
  //
  $arStrES = array("��","��","��","��","��","��","��","��","��","��","��","��","��","��");
  $arStrOS = array("�","�","�","��","�","��","��","��","��","�","��","��","��","��");        
  $arStrRS = array("�$","�$","�$","�$","�$","�$","�$","�$","�$","�$","�$","�$","@","@");
  //            
  $replace = array("�"=>"A","�"=>"a","�"=>"B","�"=>"b","�"=>"V","�"=>"v","�"=>"G","�"=>"g","�"=>"D","�"=>"d",
          "�"=>"Ye","�"=>"e","�"=>"Ye","�"=>"e","�"=>"Zh","�"=>"zh","�"=>"Z","�"=>"z","�"=>"I","�"=>"i",
          "�"=>"Y","�"=>"y","�"=>"K","�"=>"k","�"=>"L","�"=>"l","�"=>"M","�"=>"m","�"=>"N","�"=>"n",
          "�"=>"O","�"=>"o","�"=>"P","�"=>"p","�"=>"R","�"=>"r","�"=>"S","�"=>"s","�"=>"T","�"=>"t",
          "�"=>"U","�"=>"u","�"=>"F","�"=>"f","�"=>"Kh","�"=>"kh","�"=>"Ts","�"=>"ts","�"=>"Ch","�"=>"ch",
          "�"=>"Sh","�"=>"sh","�"=>"Shch","�"=>"shch","�"=>"","�"=>"","�"=>"Y","�"=>"y","�"=>"","�"=>"",
          "�"=>"E","�"=>"e","�"=>"Yu","�"=>"yu","�"=>"Ya","�"=>"ya","@"=>"y","$"=>"ye");
  //        
  $result = str_replace($arStrES, $arStrRS, $result);
  $result = str_replace($arStrOS, $arStrRS, $result);
  $result = strtr($result, $replace);  
  //
  return $result;  
} 
// -----------------------------------------------------------------------------
/**
 *
 */
static public function getUrlCode($text = '') {
  $urlCode = '';
  //
  $urlCode = preg_replace('/[^\wa-z0-9\-]+/isu', '-', $text);
  $urlCode = mb_strtolower($urlCode);
  $urlCode = preg_replace('/-+/isu', '-', $urlCode);
  //  
  // DEBUG <<< ---      
  // echo '$text'; echo '<br>'; print_r($text); echo '<hr>';
  // echo '$urlCode'; echo '<br>'; print_r($urlCode); echo '<hr>';
  // >>> DEBUG ---
  //      
  return $urlCode;  
}
/**
 *
 */
static public function removeExtraSpaces($text = '') {
  $result = '';
  //
  $result = trim($text);
  $result = preg_replace('/\s+/isu', ' ', $result);
  //  
  // DEBUG <<< ---      
  // echo '$text'; echo '<br>'; print_r($text); echo '<hr>';          
  // >>> DEBUG ---
  //      
  return $result; 
}
// =============================================================================
}
// =============================================================================
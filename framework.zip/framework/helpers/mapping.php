<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 * 
 */   
class mapping {
// =============================================================================
/**
 *
 */
static public function apply($arFields = [], $arMapping = [], $arOptions = []) {
  $arFieldsResult = [];
  //
  if (is_object($arFields)) $arFields = get_object_vars($arFields);
  if (!is_array($arFields)) return $arFields;
  //
  foreach($arFields as $key => $value) {
    $arField = ['key' => $key, 'value' => $value];
    $sideToFind = 'key';
    $sidesToReplace = ['key'];
    if ($key === $value) {
      $sideToFind = 'key';
      $sidesToReplace = ['key', 'value'];
    } elseif(is_integer($key)) {
      $sideToFind = 'value';
      $sidesToReplace = ['value'];
    }
    $replacement = false;
    $whatToFind = $arField[$sideToFind];
    $whatReplace = '';
    if (!empty($arOptions['separator'])) {
      $arValue = explode($arOptions['separator'], $arField[$sideToFind]);
      if (count($arValue) >= 2) { 
        $whatToFind = $whatReplace = $arValue[0];
      }        
    }    
    if (!empty($arMapping[$whatToFind])) {
      $replacement = $arMapping[$whatToFind];
    }    
    if (!empty($replacement)) {
      foreach($sidesToReplace as $side) {        
        if (!empty($whatReplace)) {
          $arField[$side] = str_ireplace($whatReplace, $replacement, $arField[$side]);
        } else {
          $arField[$side] = $replacement;
        }
      }
      $arFieldsResult[$arField['key']] = $arField['value'];
    } elseif(empty($arOptions['only'])) {
      $arFieldsResult[$key] = $value;
    }    
  }
  //
  // DEBUG <<< ---  
  // echo '$arFields'; echo '<br>'; print_r($arFields); echo '<hr>';
  // echo '$arMapping'; echo '<br>'; print_r($arMapping); echo '<hr>';
  // echo '$arFieldsResult'; echo '<br>'; print_r($arFieldsResult); echo '<hr>';
  // echo '<hr>'; echo '<hr>'; echo '<hr>';  
  // >>> DEBUG ---
  //
  return $arFieldsResult;
}
// =============================================================================
}
// =============================================================================
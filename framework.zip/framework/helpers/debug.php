<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 *
 */
class debug {
// =============================================================================
/**
 *
 */ 
static public function printr($key = '', $value = '') {
  if (is_array($key)) {
    foreach($key as $keyInner => $valueInner) {
      self::printrOne($keyInner, $valueInner);
    }
  } else self::printrOne($key, $value);
}
/**
 *
 */
static private function printrOne($key = '', $value = '') {
  echo $key; echo '<br>'; print_r($value); echo '<hr>';
}
// =============================================================================
}
// =============================================================================
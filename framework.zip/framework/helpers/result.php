<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\helpers;
// =============================================================================
/**
 *
 */   
class result {
// =============================================================================
/**
 *
 */ 
static public function merge($arResultParent = [], $arResultCurrent = []) {
  $arResultParent = self::mergeErrorsNotes($arResultParent, $arResultCurrent);
  //
  if (isset($arResultParent['arStats']) && isset($arResultCurrent['arStats'])) {
    $arResultParent['arStats'] = self::mergeStats($arResultParent['arStats'], $arResultCurrent['arStats']);
  }
  if (isset($arResultCurrent['status']) && isset($arResultParent['arStats'])) {
    if (isset($arResultParent['arStats'][$arResultCurrent['status']])) {
      $arResultParent['arStats'][$arResultCurrent['status']]++;
    }
  }
  //
  return $arResultParent;
}
/**
 *
 */
static public function mergeReturn(&$arResultParent = [], $arResultCurrent = []) {
  $arResultToReturn = [];
  //
  $arResultParent = self::merge($arResultParent, $arResultCurrent);
  if (isset($arResultCurrent['arData'])) {
    $arResultToReturn = $arResultCurrent['arData'];
  } else if (isset($arResultCurrent['status'])) {
    $arResultToReturn = $arResultCurrent['status'];     
  } else {
    $arResultToReturn = $arResultCurrent;
  }
  //
  return $arResultToReturn;    
}
// -----------------------------------------------------------------------------
/**
 *
 */
static public function mergeErrorsNotes($arResultParent = [], $arResultCurrent = []) {
  foreach(['arErrors', 'arNotes'] as $field) {
    if (isset($arResultParent[$field]) && isset($arResultCurrent[$field])) {
      $arResultParent[$field] = array_merge($arResultParent[$field], $arResultCurrent[$field]);
    }
  }
  //
  return $arResultParent;    
} 
/**
 *
 */
static public function mergeStats($arStatsParent = [], $arStatsCurrent = []) {
  if (!empty($arStatsCurrent)) {
    foreach($arStatsCurrent as $key => $value) {
      if (is_array($value)) {
        $arStatsParent[$key] = self::mergeStats($arStatsParent[$key], $arStatsCurrent[$key]);
      } else {
        if (!isset($arStatsParent[$key])) {
          $arStatsParent[$key] = 0;
        }
        $arStatsParent[$key] += $arStatsCurrent[$key];
      }  
    }
  }
  return $arStatsParent;
}  
// =============================================================================
}
// =============================================================================
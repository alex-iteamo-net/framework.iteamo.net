<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework;
// =============================================================================
require_once(__dir__ . '/traits/withSettings.php');
require_once(__dir__ . '/helpers/path.php');
require_once(__dir__ . '/helpers/arrays.php');
require_once(__dir__ . '/helpers/classes.php');
// =============================================================================
/**
 *
 */
class app {
// =============================================================================
use \iteamo\framework\traits\withSettings;
// -----------------------------------------------------------------------------
/**
 *
 */
public function __construct() {   
  spl_autoload_register([$this, 'autoload']);
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function setPaths($arPaths = []) {
  if (!isset($this->arPaths)) {
    $this->arPaths = [];
  }  
  $this->arPaths = helpers\arrays::set($this->arPaths, $arPaths);      
}
/**
 *
 */
public function setPath($key = '', $value = '') {
  $this->setPaths([$key => $value]);
}
/**
 *
 */
protected function getPaths($mixKeys = null) {
  $mixResult = null;
  //
  if (!isset($this->arPaths)) {
    $this->arPaths = [
      'root' => dirname(static::getInfo('path')),
    ];                     
  }
  $mixResult = helpers\arrays::get($this->arPaths, $mixKeys);
  //
  // DEBUG <<< ---      
  // echo '$mixResult'; echo '<br>'; print_r($mixResult); echo '<hr>';  
  // >>> DEBUG ---  
  //    
  return $mixResult;
}
/**
 *
 */
public function getPath($key = 'root', $mixOptions = null) {
  $path = null;
  //      
  $path = $this->getPaths($key);  
  //  
  if (empty($path)) {        
    $keyFormatted = helpers\path::format($key);    
    if ($keyFormatted{0} == '/') {
      $directory = helpers\path::getDocumentRoot();
      if (stripos($keyFormatted, '/iteamo/') === 0) {
        $directory = realpath(__dir__ . '/../../');
      }                          
    } else {    
      $keyFormatted = '/' . $keyFormatted;
      $directory = $this->getPath();      
    }          
    $pathTemp = $directory . $keyFormatted;    
    if (file_exists($pathTemp)) {
      $path = $pathTemp;
    }
  }
  //
  if (!empty($path) && $mixOptions === 'relative') {
    $path = helpers\path::getRelative($path);  
  } 
  //
  // DEBUG <<< ---
  // if ($key == 'templates/test.php') {
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';    
  // echo 'get_class($this)'; echo '<br>'; print_r(get_class($this)); echo '<hr>';    
  // echo '$path'; echo '<br>'; print_r($path); echo '<hr>';
  // echo '<hr>';
  // }
  // >>> DEBUG ---  
  // 
  return $path;     
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function getClass($key = '', $arOptions = []) {      
  $class = null; 
  //  
  $keyFormatted = helpers\classes::format($key);  
  if (class_exists($keyFormatted, false) || trait_exists($keyFormatted, false)) {     
    $class = $keyFormatted;
  } else {                      
    $path = $this->getPath($key . '.php', $arOptions);            
    if (!empty($path)) {      
      require_once($path);          
      if ($keyFormatted{0} != '\\') {
        $keyFormatted = static::getInfo('namespace') . '\\' . $keyFormatted;      
      }      
      if (class_exists($keyFormatted, false) || trait_exists($keyFormatted, false)) {
        $class = $keyFormatted;  
      }
    }    
  }
  if (empty($class) && empty($arOptions['withoutException'])) {
    throw new \exception('Class could not been found for key: ' . $key);
  }
  //
  // DEBUG <<< ---
  // echo 'static::getInfo(class)'; echo '<br>'; print_r(static::getInfo('class')); echo '<hr>';
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$arOptions'; echo '<br>'; print_r($arOptions); echo '<hr>';
  // echo '$keyFormatted'; echo '<br>'; print_r($keyFormatted); echo '<hr>';
  // echo '$path'; echo '<br>'; print_r($path); echo '<hr>';    
  // echo '$class'; echo '<br>'; print_r($class); echo '<hr>';
  // echo '<hr>'; 
  // >>> DEBUG ---  
  //  
  return $class;
}
/**
 *
 */
public function getObject($key = '', $arParams = [], $checkSingleton = false) {
  $objEct = null;
  // 
  $class = $this->getClass($key);
  //    
  if (!empty($class)) {       
    $objEct = ($checkSingleton && method_exists($class, 'get')) ? $class::get($arParams) : new $class($arParams);     
    if (!is_object($objEct)) {
      $objEct = new $class($arParams);   
    }
  }
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$class'; echo '<br>'; print_r($class); echo '<hr>';
  // echo '$objEct'; echo '<br>'; print_r($objEct); echo '<hr>';
  // echo '<hr>';
  // >>> DEBUG ---  
  //
  return $objEct;
}
/**
 *
 */
public function getApp($key = '', $arParams = []) {
  $objApp = null;
  //
  $keyPrepared = $key . '/app';
  if ($key == 'parent') {
    $keyPrepared = $this::getInfo('parentClass');      
  }  
  $objApp = $this->getObject($keyPrepared);  
  //
  // DEBUG <<< ---
  // echo '$key'; echo '<br>'; print_r($key); echo '<hr>';
  // echo '$keyPrepared'; echo '<br>'; print_r($keyPrepared); echo '<hr>';
  // echo '$objApp'; echo '<br>'; print_r($objApp); echo '<hr>';
  // echo 'get_class($this)'; echo '<br>'; print_r(get_class($this)); echo '<hr>';
  // echo 'get_class($objApp)'; echo '<br>'; print_r(get_class($objApp)); echo '<hr>';
  // >>> DEBUG ---  
  //
  return $objApp;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public function setHelper($key = '', $objHelper = null) {
  if (is_object($objHelper)) {
    if (!isset($this->arHelpers)) {
      $this->arHelpers = [];
    }
    $this->arHelpers[$key] = $objHelper;
  }
}
/**
 *
 */
public function getHelper($key = '') {
  $objHelper = null;
  //   
  if (empty($this->arHelpers[$key])) {
    $keyPrepared = ($key{0} != '/') ? 'helpers/' . $key : $key;
    $objHelper = $this->getObject($keyPrepared, $arParams = [], $checkSingleton = false);    
    $this->setHelper($key, $objHelper);
  }
  $objHelper = $this->arHelpers[$key]; 
  //
  return $objHelper;
}
// -----------------------------------------------------------------------------
/**
 *
 */
public static function getInfo($mixKeys = null) {
  $mixResult = [];
  //
  static $arCache = [];
  if (!array_key_exists(static::class, $arCache)) {
    $arCache[static::class] = helpers\classes::getInfo(static::class);
  }
  $arClassInfo = $arCache[static::class];
  $mixResult = helpers\arrays::get($arClassInfo, $mixKeys);
  //
  // DEBUG <<< ---
  // if (static::class == 'iteamo\apps\map\app') {
    // echo '$mixKeys'; echo '<br>'; print_r($mixKeys); echo '<hr>';      
    // echo '$mixResult'; echo '<br>'; print_r($mixResult); echo '<hr>';
    // echo 'static::class'; echo '<br>'; print_r(static::class); echo '<hr>';
  // } 
  // >>> DEBUG ---  
  //  
  return $mixResult;
}
/**
 *
 */
public static function __callStatic($method = '', $arParams = []) {  
  $mixResult = null;
  //  
  $objSelf = (method_exists(static::class, 'get')) ? static::get() : new static();
  $mixResult = call_user_func_array([$objSelf, $method], $arParams);
  //
  return $mixResult;
}
/**
 *
 */
protected function autoload($class = '') {  
  if (stripos($class, static::getInfo('namespace')) !== false) {            
    $classResult = $this->getClass('\\' . $class);
  }
  //
  // DEBUG <<< ---  
  // echo '$class'; echo '<br>'; print_r($class); echo '<hr>';      
  // echo 'static::getInfo(namespace)'; echo '<br>'; print_r(static::getInfo('namespace')); echo '<hr>';
  // echo '$classResult'; echo '<br>'; print_r($classResult); echo '<hr>';  
  // >>> DEBUG ---
}
// =============================================================================
}
// =============================================================================
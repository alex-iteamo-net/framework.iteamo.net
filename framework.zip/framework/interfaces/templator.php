<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\interfaces;
// =============================================================================
/**
 *
 */ 
interface templator {
// =============================================================================
public function setData($arData = []);
public function parse($path = '');
// =============================================================================
}
// =============================================================================
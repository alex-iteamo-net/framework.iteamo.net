<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\framework\interfaces;
// =============================================================================
/**
 *
 */ 
interface translator {
// =============================================================================
public function setCurrentLanguage($language = '');
public function getCurrentLanguage();
public function get($key = '', $arTranslations = [], $returnKey = true);
//
public function isValid($language = '');
public function isDefault($language = '');
// =============================================================================
}
// =============================================================================
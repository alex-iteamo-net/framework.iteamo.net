<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace /test;
class app {
  static $arSettings = [];  
  public function getHelper() {
    static $counter = 0;
    $counter++;
    echo $counter . '<hr>';
  }      
}
$objApp = new app();
$objApp2 = new app();
$objApp->getHelper();
$objApp::getHelper();
$objApp2::getHelper();
$objApp2->getHelper();
//
// =============================================================================  
// DEBUG <<< ---
// echo '$variable'; echo '<br>'; print_r($variable); echo '<hr>';
// echo '$advFilterListSource'; echo '<br>'; print_r($advFilterListSource); echo '<hr>';
// echo '$advFilterListResult'; echo '<br>'; print_r($advFilterListResult); echo '<hr>';
// die();
// >>> DEBUG ---
// ============================================================================= 
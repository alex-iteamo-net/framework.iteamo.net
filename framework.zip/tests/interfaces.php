<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
//
$bar = $foo ?? $baz ?? 'default';
//
class \test\app {

}
//
// =============================================================================  
// DEBUG <<< ---
echo '$bar'; echo '<br>'; print_r($bar); echo '<hr>';
// >>> DEBUG ---
// ============================================================================= 
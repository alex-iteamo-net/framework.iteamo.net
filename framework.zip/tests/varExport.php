<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
namespace iteamo\tests;
// =============================================================================
require_once($_SERVER['DOCUMENT_ROOT'] . '/iteamo/framework/helpers/dataFile.php');
use \iteamo\framework\helpers\dataFile;
// =============================================================================
//
$arData = [
  ['name' => '1111', 'description' => '2222222'],
  ['name' => '2222', 'description' => '2222'],
  'asdf' => ['name' => '333', 'description' => '33'], 
];
$strData = var_export($arData, $return = true);
$strData = str_ireplace('array (', '[', $strData);
$strData = str_ireplace(')', ']', $strData);
$strData = preg_replace('/\>[^\[\]]+\[/isu', '> [', $strData);
//
$path = __dir__ . '/test.data';
dataFile::write($path, $arData);
$arData = dataFile::read($path);
//
// =============================================================================  
// DEBUG <<< ---
// echo '$arData'; echo '<br>'; print_r($arData); echo '<hr>';
// echo '$strData'; echo '<br>'; print_r($strData); echo '<hr>';
echo '$arData'; echo '<br>'; print_r($arData); echo '<hr>';
// die();
// >>> DEBUG ---
// ============================================================================= 
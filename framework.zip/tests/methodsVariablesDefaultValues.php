<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
$test2 = 'asdf';
class arrays {
  public $test = 'defualt';
  public function get($var = $test2) {
    echo $var;
  }  
}
$objArray = new arrays();
$objArray->get();
//
// =============================================================================  
// DEBUG <<< ---
// echo '$variable'; echo '<br>'; print_r($variable); echo '<hr>';
// echo '$advFilterListSource'; echo '<br>'; print_r($advFilterListSource); echo '<hr>';
// echo '$advFilterListResult'; echo '<br>'; print_r($advFilterListResult); echo '<hr>';
// die();
// >>> DEBUG ---
// ============================================================================= 
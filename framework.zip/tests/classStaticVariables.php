<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
class a {
  static public function getSettings() {
    static $arSettings = [];
    if (empty($arSettings)) {
      $arSettings = ['class' => get_called_class()];
      echo 'notCache:';  
    }
    return $arSettings;
  } 
}
class b extends a {
}
$a = new a();
$b = new b();
$c = new a();
print_r($a::getSettings()); echo '<hr>';
print_r($b::getSettings()); echo '<hr>';
print_r($a::getSettings()); echo '<hr>';
print_r($a::getSettings()); echo '<hr>';
print_r($b::getSettings()); echo '<hr>';
print_r(b::getSettings()); echo '<hr>';
print_r(a::getSettings()); echo '<hr>';
print_r($c::getSettings()); echo '<hr>';
//
// =============================================================================  
// DEBUG <<< ---
// echo '$variable'; echo '<br>'; print_r($variable); echo '<hr>';
// echo '$advFilterListSource'; echo '<br>'; print_r($advFilterListSource); echo '<hr>';
// echo '$advFilterListResult'; echo '<br>'; print_r($advFilterListResult); echo '<hr>';
// die();
// >>> DEBUG ---
// ============================================================================= 
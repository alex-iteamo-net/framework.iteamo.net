<?
// ALEX.ITEAMO.NET <<< =========================================================
// Alex Tert. Web-development. CRM, ERP, VOIP, LMS, cloud services integration
// Web: alex.iTeamo.net  Skype: alexITmore  ICQ: 235004598  Mail: alex@iteamo.net
// =============================================================================
$text = 'asdzxx;lkjlkxxlx';
$regularExpression = '/[^x]/isu';
$textResult = preg_replace($regularExpression, '', $text);
//
// =============================================================================  
// DEBUG <<< ---
echo '$text'; echo '<br>'; print_r($text); echo '<hr>';
echo '$textResult'; echo '<br>'; print_r($textResult); echo '<hr>';
// >>> DEBUG ---
// ============================================================================= 